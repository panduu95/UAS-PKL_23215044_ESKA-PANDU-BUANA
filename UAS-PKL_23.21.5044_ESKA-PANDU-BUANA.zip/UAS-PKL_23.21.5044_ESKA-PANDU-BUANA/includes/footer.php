        </main>
        <footer class="footer">
            <span>© <?= date('Y') ?> Konten Planner SMK Bhakti Praja Adiwerna</span>
            <span>Capstone Project PKL — Eska Pandu Buana (23.21.5044)</span>
        </footer>
    </div>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>
