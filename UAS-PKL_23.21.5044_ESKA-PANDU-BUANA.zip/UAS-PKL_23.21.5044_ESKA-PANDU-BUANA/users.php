<?php
require __DIR__ . '/bootstrap.php';
require_role('admin');

$pageTitle = 'Pengguna';
$activePage = 'users';

if (is_post()) {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? 'save');

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id === (int) current_user()['id']) {
            flash('danger', 'Akun yang sedang digunakan tidak dapat dihapus.');
            redirect('users.php');
        }
        $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
        $stmt->execute([$id]);
        flash('success', 'Pengguna berhasil dihapus.');
        redirect('users.php');
    }

    $id = (int) ($_POST['id'] ?? 0);
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = trim(strtolower((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');
    $role = (string) ($_POST['role'] ?? 'team');

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !in_array($role, ['admin', 'team', 'humas'], true)) {
        flash('danger', 'Nama, email, dan peran wajib diisi dengan benar.');
        redirect($id ? 'users.php?edit=' . $id . '#user-form' : 'users.php#user-form');
    }
    if ($id === (int) current_user()['id'] && $role !== 'admin') {
        flash('danger', 'Peran akun admin yang sedang digunakan tidak dapat diubah.');
        redirect('users.php?edit=' . $id . '#user-form');
    }
    if ($id === 0 && strlen($password) < 6) {
        flash('danger', 'Kata sandi pengguna baru minimal 6 karakter.');
        redirect('users.php#user-form');
    }

    try {
        if ($id > 0) {
            if ($password !== '') {
                if (strlen($password) < 6) {
                    flash('danger', 'Kata sandi baru minimal 6 karakter.');
                    redirect('users.php?edit=' . $id . '#user-form');
                }
                $stmt = $pdo->prepare('UPDATE users SET name = ?, email = ?, password = ?, role = ? WHERE id = ?');
                $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $role, $id]);
            } else {
                $stmt = $pdo->prepare('UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?');
                $stmt->execute([$name, $email, $role, $id]);
            }
            if ($id === (int) current_user()['id']) {
                $_SESSION['user']['name'] = $name;
                $_SESSION['user']['email'] = $email;
                $_SESSION['user']['role'] = $role;
            }
            flash('success', 'Data pengguna berhasil diperbarui.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
            $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $role]);
            flash('success', 'Pengguna baru berhasil ditambahkan.');
        }
    } catch (PDOException $e) {
        if (str_contains($e->getMessage(), 'UNIQUE')) {
            flash('danger', 'Email sudah digunakan oleh akun lain.');
        } else {
            throw $e;
        }
    }
    redirect('users.php');
}

$editUser = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT id, name, email, role FROM users WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editUser = $stmt->fetch() ?: null;
}

$users = $pdo->query("SELECT u.*,
    (SELECT COUNT(*) FROM contents c WHERE c.assigned_user_id = u.id) AS content_count,
    (SELECT COUNT(*) FROM tasks t WHERE t.assigned_user_id = u.id) AS task_count
    FROM users u ORDER BY CASE u.role WHEN 'admin' THEN 1 WHEN 'team' THEN 2 ELSE 3 END, u.name")->fetchAll();

require BASE_PATH . '/includes/header.php';
?>

<div class="layout-split">
    <section class="panel">
        <div class="panel-header"><div><h2>Daftar Pengguna</h2><p><?= count($users) ?> akun memiliki akses ke sistem.</p></div><a class="btn btn-primary" href="#user-form">+ Tambah Pengguna</a></div>
        <div class="user-list">
            <?php foreach ($users as $item): ?>
                <article class="user-card">
                    <div class="avatar avatar-large"><?= e(strtoupper(mb_substr($item['name'], 0, 1))) ?></div>
                    <div class="user-card-copy">
                        <div><h3><?= e($item['name']) ?></h3><span class="badge badge-<?= $item['role'] === 'admin' ? 'primary' : ($item['role'] === 'team' ? 'info' : 'warning') ?>"><?= e(role_label($item['role'])) ?></span></div>
                        <p><?= e($item['email']) ?></p>
                        <small><?= (int) $item['content_count'] ?> konten · <?= (int) $item['task_count'] ?> tugas</small>
                    </div>
                    <div class="inline-actions">
                        <a class="btn btn-small btn-secondary" href="users.php?edit=<?= (int) $item['id'] ?>#user-form">Edit</a>
                        <?php if ((int) $item['id'] !== (int) current_user()['id']): ?>
                            <form method="post" data-confirm="Hapus akun ini? Data konten dan tugas tetap tersimpan, tetapi penanggung jawab akan dikosongkan.">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                                <button class="btn btn-small btn-danger-ghost" type="submit">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <aside class="panel form-panel" id="user-form">
        <div class="panel-header">
            <div><h2><?= $editUser ? 'Edit Pengguna' : 'Tambah Pengguna' ?></h2><p>Atur akun dan hak akses sesuai peran di tim media sosial.</p></div>
            <?php if ($editUser): ?><a class="text-link" href="users.php#user-form">Batal</a><?php endif; ?>
        </div>
        <form method="post" class="stack-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($editUser['id'] ?? 0) ?>">
            <label><span>Nama lengkap *</span><input type="text" name="name" required value="<?= e($editUser['name'] ?? '') ?>"></label>
            <label><span>Email *</span><input type="email" name="email" required value="<?= e($editUser['email'] ?? '') ?>"></label>
            <label><span>Kata sandi <?= $editUser ? '(kosongkan bila tidak diubah)' : '*' ?></span><input type="password" name="password" <?= $editUser ? '' : 'required' ?> minlength="6"></label>
            <label><span>Peran</span>
                <select name="role">
                    <?php foreach (['admin' => 'Admin Media Sosial', 'team' => 'Tim Konten', 'humas' => 'Humas / Pihak Sekolah'] as $key => $label): ?>
                        <option value="<?= e($key) ?>" <?= selected($editUser['role'] ?? 'team', $key) ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <div class="role-help">
                <strong>Hak akses singkat</strong>
                <p><b>Admin:</b> mengelola semua data dan pengguna.</p>
                <p><b>Tim:</b> membuat konten, memperbarui tugas, dan menginput engagement.</p>
                <p><b>Humas:</b> melihat kalender/laporan dan memberikan feedback.</p>
            </div>
            <button class="btn btn-primary btn-block" type="submit"><?= $editUser ? 'Simpan Perubahan' : 'Tambahkan Pengguna' ?></button>
        </form>
    </aside>
</div>

<?php require BASE_PATH . '/includes/footer.php'; ?>
