(() => {
    const sidebar = document.getElementById('sidebar');
    document.querySelectorAll('[data-toggle-sidebar]').forEach((button) => {
        button.addEventListener('click', () => sidebar?.classList.toggle('open'));
    });

    document.addEventListener('click', (event) => {
        if (window.innerWidth <= 980 && sidebar?.classList.contains('open')) {
            const inside = sidebar.contains(event.target);
            const toggle = event.target.closest('[data-toggle-sidebar]');
            if (!inside && !toggle) sidebar.classList.remove('open');
        }
    });

    document.querySelectorAll('[data-dismiss-alert]').forEach((button) => {
        button.addEventListener('click', () => button.closest('.alert')?.remove());
    });

    document.querySelectorAll('[data-auto-dismiss]').forEach((alert) => {
        window.setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-5px)';
            window.setTimeout(() => alert.remove(), 250);
        }, 4500);
    });

    document.querySelectorAll('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            if (!window.confirm(form.dataset.confirm || 'Lanjutkan tindakan ini?')) {
                event.preventDefault();
            }
        });
    });

    document.querySelectorAll('[data-toggle-password]').forEach((button) => {
        button.addEventListener('click', () => {
            const input = document.querySelector(button.dataset.togglePassword);
            if (!input) return;
            const showing = input.type === 'text';
            input.type = showing ? 'password' : 'text';
            button.textContent = showing ? 'Lihat' : 'Sembunyikan';
        });
    });

    const engagementSelect = document.querySelector('[data-engagement-content]');
    if (engagementSelect) {
        engagementSelect.addEventListener('change', () => {
            if (engagementSelect.value) {
                window.location.href = `engagement.php?content_id=${encodeURIComponent(engagementSelect.value)}#engagement-form`;
            }
        });
    }

    const charts = window.dashboardCharts;
    if (charts) {
        drawBarChart(document.getElementById('statusChart'), ['To Do', 'On Progress', 'Review', 'Published'], charts.status, ['#9ab8df', '#3f87d8', '#e5ad42', '#2ca77d']);
        drawDonutChart(document.getElementById('platformChart'), charts.platformLabels, charts.platformData, ['#c7568e', '#228e96', '#d95252', '#4c74bf', '#7455bd']);
    }

    function setupCanvas(canvas) {
        if (!canvas) return null;
        const ratio = window.devicePixelRatio || 1;
        const rect = canvas.getBoundingClientRect();
        const width = Math.max(300, rect.width || Number(canvas.getAttribute('width')) || 400);
        const height = Math.max(220, rect.height || Number(canvas.getAttribute('height')) || 250);
        canvas.width = width * ratio;
        canvas.height = height * ratio;
        const ctx = canvas.getContext('2d');
        ctx.scale(ratio, ratio);
        return { ctx, width, height };
    }

    function drawBarChart(canvas, labels, values, colors) {
        const setup = setupCanvas(canvas);
        if (!setup) return;
        const { ctx, width, height } = setup;
        const pad = { top: 20, right: 15, bottom: 42, left: 38 };
        const chartWidth = width - pad.left - pad.right;
        const chartHeight = height - pad.top - pad.bottom;
        const maxValue = Math.max(4, ...values);
        const step = Math.ceil(maxValue / 4);
        const maxAxis = step * 4;

        ctx.font = '10px system-ui, sans-serif';
        ctx.textBaseline = 'middle';
        for (let i = 0; i <= 4; i++) {
            const y = pad.top + (chartHeight / 4) * i;
            ctx.beginPath();
            ctx.strokeStyle = '#e8edf4';
            ctx.lineWidth = 1;
            ctx.moveTo(pad.left, y);
            ctx.lineTo(width - pad.right, y);
            ctx.stroke();
            ctx.fillStyle = '#8794a5';
            ctx.textAlign = 'right';
            ctx.fillText(String(maxAxis - step * i), pad.left - 8, y);
        }

        const slot = chartWidth / Math.max(1, values.length);
        const barWidth = Math.min(58, slot * 0.48);
        values.forEach((value, index) => {
            const h = maxAxis > 0 ? (value / maxAxis) * chartHeight : 0;
            const x = pad.left + slot * index + (slot - barWidth) / 2;
            const y = pad.top + chartHeight - h;
            roundRect(ctx, x, y, barWidth, h, 6, colors[index % colors.length]);
            ctx.fillStyle = '#25364a';
            ctx.font = '700 11px system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(String(value), x + barWidth / 2, Math.max(pad.top + 8, y - 9));
            ctx.fillStyle = '#65758a';
            ctx.font = '9px system-ui, sans-serif';
            ctx.fillText(labels[index], x + barWidth / 2, height - 17);
        });
    }

    function roundRect(ctx, x, y, width, height, radius, fill) {
        if (height <= 0) return;
        const r = Math.min(radius, width / 2, height / 2);
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + width, y, x + width, y + height, r);
        ctx.arcTo(x + width, y + height, x, y + height, r);
        ctx.arcTo(x, y + height, x, y, r);
        ctx.arcTo(x, y, x + width, y, r);
        ctx.closePath();
        ctx.fillStyle = fill;
        ctx.fill();
    }

    function drawDonutChart(canvas, labels, values, colors) {
        const setup = setupCanvas(canvas);
        if (!setup) return;
        const { ctx, width, height } = setup;
        const total = values.reduce((sum, value) => sum + Number(value), 0);
        const cx = Math.min(width * 0.37, 150);
        const cy = height / 2;
        const radius = Math.min(75, height * 0.31);
        const lineWidth = Math.max(20, radius * 0.38);

        if (total <= 0) {
            ctx.beginPath();
            ctx.strokeStyle = '#e7ecf3';
            ctx.lineWidth = lineWidth;
            ctx.arc(cx, cy, radius, 0, Math.PI * 2);
            ctx.stroke();
        } else {
            let angle = -Math.PI / 2;
            values.forEach((value, index) => {
                const slice = (Number(value) / total) * Math.PI * 2;
                ctx.beginPath();
                ctx.strokeStyle = colors[index % colors.length];
                ctx.lineWidth = lineWidth;
                ctx.lineCap = 'butt';
                ctx.arc(cx, cy, radius, angle, angle + slice);
                ctx.stroke();
                angle += slice;
            });
        }

        ctx.textAlign = 'center';
        ctx.fillStyle = '#172033';
        ctx.font = '800 23px system-ui, sans-serif';
        ctx.fillText(String(total), cx, cy - 2);
        ctx.fillStyle = '#7a8899';
        ctx.font = '9px system-ui, sans-serif';
        ctx.fillText('TOTAL KONTEN', cx, cy + 17);

        const legendX = Math.min(width * 0.68, width - 110);
        let legendY = Math.max(35, cy - ((labels.length - 1) * 24) / 2);
        labels.forEach((label, index) => {
            ctx.beginPath();
            ctx.fillStyle = colors[index % colors.length];
            ctx.arc(legendX, legendY, 5, 0, Math.PI * 2);
            ctx.fill();
            ctx.textAlign = 'left';
            ctx.fillStyle = '#536477';
            ctx.font = '10px system-ui, sans-serif';
            ctx.fillText(`${label} (${values[index]})`, legendX + 12, legendY + 1);
            legendY += 24;
        });
    }
})();
