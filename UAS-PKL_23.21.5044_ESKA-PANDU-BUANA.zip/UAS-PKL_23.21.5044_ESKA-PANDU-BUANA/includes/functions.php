<?php

declare(strict_types=1);

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): never
{
    header('Location: ' . $path);
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function pull_flashes(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

function csrf_token(): string
{
    return $_SESSION['csrf_token'] ?? '';
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals(csrf_token(), (string) $token)) {
        http_response_code(419);
        exit('Token keamanan tidak valid. Silakan muat ulang halaman dan coba kembali.');
    }
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function format_date(?string $date, string $format = 'd M Y'): string
{
    if (!$date) {
        return '-';
    }
    try {
        return (new DateTime($date))->format($format);
    } catch (Throwable) {
        return $date;
    }
}

function format_datetime(?string $date): string
{
    return format_date($date, 'd M Y, H:i');
}

function status_class(string $status): string
{
    return match (strtolower($status)) {
        'published', 'selesai', 'done', 'approved' => 'success',
        'review', 'menunggu review' => 'warning',
        'on progress', 'in progress', 'dikerjakan' => 'info',
        'archived', 'dibatalkan', 'cancelled' => 'muted',
        default => 'primary',
    };
}

function role_label(string $role): string
{
    return match ($role) {
        'admin' => 'Admin Media Sosial',
        'team' => 'Tim Konten',
        'humas' => 'Humas / Pihak Sekolah',
        default => ucfirst($role),
    };
}

function selected(string|int|null $a, string|int|null $b): string
{
    return (string) $a === (string) $b ? 'selected' : '';
}

function checked(bool $condition): string
{
    return $condition ? 'checked' : '';
}

function excerpt(?string $text, int $length = 80): string
{
    $text = trim((string) $text);
    if (mb_strlen($text) <= $length) {
        return $text;
    }
    return mb_substr($text, 0, $length - 1) . '…';
}

function upload_file(array $file, int $contentId): ?array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Unggah file gagal. Kode: ' . ($file['error'] ?? 'tidak diketahui'));
    }

    $maxSize = 8 * 1024 * 1024;
    if (($file['size'] ?? 0) > $maxSize) {
        throw new RuntimeException('Ukuran file maksimal 8 MB.');
    }

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'video/mp4' => 'mp4',
        'application/pdf' => 'pdf',
    ];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Format file tidak didukung. Gunakan JPG, PNG, WEBP, MP4, atau PDF.');
    }

    $uploadDir = BASE_PATH . '/uploads';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0775, true);
    }

    $safeName = 'content_' . $contentId . '_' . bin2hex(random_bytes(6)) . '.' . $allowed[$mime];
    $target = $uploadDir . '/' . $safeName;
    if (!move_uploaded_file($file['tmp_name'], $target)) {
        throw new RuntimeException('File tidak dapat disimpan ke folder uploads.');
    }

    return [
        'original_name' => basename((string) $file['name']),
        'stored_name' => $safeName,
        'mime_type' => $mime,
        'size_bytes' => (int) $file['size'],
        'path' => 'uploads/' . $safeName,
    ];
}
