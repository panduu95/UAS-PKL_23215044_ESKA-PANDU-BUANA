<?php
require __DIR__ . '/bootstrap.php';
require_login();

$pageTitle = 'Engagement';
$activePage = 'engagement';
$canEdit = in_array(current_user()['role'], ['admin', 'team'], true);

if (is_post()) {
    verify_csrf();
    if (!$canEdit) {
        http_response_code(403);
        exit('Akses ditolak.');
    }

    $contentId = (int) ($_POST['content_id'] ?? 0);
    $views = max(0, (int) ($_POST['views'] ?? 0));
    $likes = max(0, (int) ($_POST['likes'] ?? 0));
    $comments = max(0, (int) ($_POST['comments'] ?? 0));
    $shares = max(0, (int) ($_POST['shares'] ?? 0));
    $reach = max(0, (int) ($_POST['reach'] ?? 0));
    $saves = max(0, (int) ($_POST['saves'] ?? 0));

    if ($contentId <= 0) {
        flash('danger', 'Pilih konten yang akan dicatat performanya.');
        redirect('engagement.php#engagement-form');
    }

    $stmt = $pdo->prepare("INSERT INTO engagements (content_id, views, likes, comments, shares, reach, saves, recorded_at, recorded_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
        ON CONFLICT(content_id) DO UPDATE SET
            views = excluded.views,
            likes = excluded.likes,
            comments = excluded.comments,
            shares = excluded.shares,
            reach = excluded.reach,
            saves = excluded.saves,
            recorded_at = CURRENT_TIMESTAMP,
            recorded_by = excluded.recorded_by");
    $stmt->execute([$contentId, $views, $likes, $comments, $shares, $reach, $saves, current_user()['id']]);

    $stmt = $pdo->prepare("UPDATE contents SET status = CASE WHEN status = 'Archived' THEN status ELSE 'Published' END, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
    $stmt->execute([$contentId]);

    flash('success', 'Data engagement berhasil disimpan.');
    redirect('engagement.php?content_id=' . $contentId . '#engagement-form');
}

$selectedContentId = (int) ($_GET['content_id'] ?? 0);
$selectedEngagement = null;
if ($selectedContentId > 0) {
    $stmt = $pdo->prepare('SELECT * FROM engagements WHERE content_id = ?');
    $stmt->execute([$selectedContentId]);
    $selectedEngagement = $stmt->fetch() ?: null;
}

$contents = $pdo->query("SELECT id, title, platform, status FROM contents WHERE status != 'Archived' ORDER BY title")->fetchAll();

$rows = $pdo->query("SELECT c.id AS content_id, c.title, c.platform, c.content_format, c.scheduled_at,
    e.views, e.likes, e.comments, e.shares, e.reach, e.saves, e.recorded_at,
    (e.likes + e.comments + e.shares + e.saves) AS interactions
    FROM engagements e
    JOIN contents c ON c.id = e.content_id
    ORDER BY interactions DESC, e.views DESC")->fetchAll();

$totals = $pdo->query("SELECT COALESCE(SUM(views), 0) AS views,
    COALESCE(SUM(likes), 0) AS likes,
    COALESCE(SUM(comments), 0) AS comments,
    COALESCE(SUM(shares), 0) AS shares,
    COALESCE(SUM(reach), 0) AS reach,
    COALESCE(SUM(saves), 0) AS saves
    FROM engagements")->fetch();

require BASE_PATH . '/includes/header.php';
?>

<section class="stats-grid stats-grid-compact engagement-summary">
    <article class="mini-stat"><span>Total Views</span><strong><?= number_format((int) $totals['views'], 0, ',', '.') ?></strong></article>
    <article class="mini-stat"><span>Total Reach</span><strong><?= number_format((int) $totals['reach'], 0, ',', '.') ?></strong></article>
    <article class="mini-stat"><span>Total Likes</span><strong><?= number_format((int) $totals['likes'], 0, ',', '.') ?></strong></article>
    <article class="mini-stat"><span>Total Interaksi</span><strong><?= number_format((int) $totals['likes'] + (int) $totals['comments'] + (int) $totals['shares'] + (int) $totals['saves'], 0, ',', '.') ?></strong></article>
</section>

<div class="layout-split <?= !$canEdit ? 'layout-single' : '' ?>">
    <section class="panel">
        <div class="panel-header"><div><h2>Performa Konten</h2><p>Data engagement yang telah dicatat setelah publikasi.</p></div></div>
        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>Konten</th><th>Views / Reach</th><th>Interaksi</th><th>Engagement Rate*</th><th>Terakhir Dicatat</th><th class="text-right">Aksi</th></tr></thead>
                <tbody>
                <?php if (!$rows): ?><tr><td colspan="6"><div class="empty-state">Belum ada data engagement.</div></td></tr><?php endif; ?>
                <?php foreach ($rows as $row): ?>
                    <?php $rate = (int) $row['reach'] > 0 ? ((int) $row['interactions'] / (int) $row['reach']) * 100 : 0; ?>
                    <tr>
                        <td><a class="table-title" href="content_detail.php?id=<?= (int) $row['content_id'] ?>"><?= e($row['title']) ?></a><span class="table-subtitle"><?= e($row['platform']) ?> · <?= e($row['content_format']) ?></span></td>
                        <td><strong><?= number_format((int) $row['views'], 0, ',', '.') ?></strong><span class="table-subtitle"><?= number_format((int) $row['reach'], 0, ',', '.') ?> reach</span></td>
                        <td><strong><?= number_format((int) $row['interactions'], 0, ',', '.') ?></strong><span class="table-subtitle"><?= number_format((int) $row['likes'], 0, ',', '.') ?> suka · <?= number_format((int) $row['comments'], 0, ',', '.') ?> komentar</span></td>
                        <td><strong><?= number_format($rate, 2, ',', '.') ?>%</strong><span class="table-subtitle">interaksi ÷ reach</span></td>
                        <td><?= e(format_datetime($row['recorded_at'])) ?></td>
                        <td class="text-right"><a class="btn btn-small btn-secondary" href="engagement.php?content_id=<?= (int) $row['content_id'] ?>#engagement-form"><?= $canEdit ? 'Edit Data' : 'Lihat' ?></a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <p class="table-note">* Engagement Rate pada aplikasi demo dihitung dari (likes + komentar + shares + saves) ÷ reach × 100%.</p>
    </section>

    <?php if ($canEdit): ?>
    <aside class="panel form-panel" id="engagement-form">
        <div class="panel-header"><div><h2>Input Engagement</h2><p>Masukkan data insight setelah konten dipublikasikan.</p></div></div>
        <form method="post" class="stack-form">
            <?= csrf_field() ?>
            <label><span>Konten *</span>
                <select name="content_id" required data-engagement-content>
                    <option value="">Pilih konten</option>
                    <?php foreach ($contents as $item): ?>
                        <option value="<?= (int) $item['id'] ?>" <?= selected($selectedContentId, $item['id']) ?>><?= e($item['title']) ?> — <?= e($item['platform']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <div class="number-grid">
                <label><span>Views</span><input type="number" name="views" min="0" value="<?= (int) ($selectedEngagement['views'] ?? 0) ?>"></label>
                <label><span>Reach</span><input type="number" name="reach" min="0" value="<?= (int) ($selectedEngagement['reach'] ?? 0) ?>"></label>
                <label><span>Likes</span><input type="number" name="likes" min="0" value="<?= (int) ($selectedEngagement['likes'] ?? 0) ?>"></label>
                <label><span>Komentar</span><input type="number" name="comments" min="0" value="<?= (int) ($selectedEngagement['comments'] ?? 0) ?>"></label>
                <label><span>Shares</span><input type="number" name="shares" min="0" value="<?= (int) ($selectedEngagement['shares'] ?? 0) ?>"></label>
                <label><span>Saves</span><input type="number" name="saves" min="0" value="<?= (int) ($selectedEngagement['saves'] ?? 0) ?>"></label>
            </div>
            <button class="btn btn-primary btn-block" type="submit">Simpan Data Engagement</button>
        </form>
    </aside>
    <?php endif; ?>
</div>

<?php require BASE_PATH . '/includes/footer.php'; ?>
