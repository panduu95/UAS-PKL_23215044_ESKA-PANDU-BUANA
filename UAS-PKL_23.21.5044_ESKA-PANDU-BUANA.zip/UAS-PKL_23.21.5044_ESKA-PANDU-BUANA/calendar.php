<?php
require __DIR__ . '/bootstrap.php';
require_login();

$pageTitle = 'Kalender Konten';
$activePage = 'calendar';

$monthParam = (string) ($_GET['month'] ?? date('Y-m'));
if (!preg_match('/^\d{4}-\d{2}$/', $monthParam)) {
    $monthParam = date('Y-m');
}

$monthStart = new DateTime($monthParam . '-01 00:00:00');
$monthEnd = (clone $monthStart)->modify('last day of this month 23:59:59');
$prevMonth = (clone $monthStart)->modify('-1 month')->format('Y-m');
$nextMonth = (clone $monthStart)->modify('+1 month')->format('Y-m');

$stmt = $pdo->prepare("SELECT c.*, u.name AS assignee_name
    FROM contents c
    LEFT JOIN users u ON u.id = c.assigned_user_id
    WHERE c.scheduled_at BETWEEN ? AND ? AND c.status != 'Archived'
    ORDER BY datetime(c.scheduled_at)");
$stmt->execute([$monthStart->format('Y-m-d H:i:s'), $monthEnd->format('Y-m-d H:i:s')]);
$contents = $stmt->fetchAll();

$byDate = [];
foreach ($contents as $content) {
    $dateKey = date('Y-m-d', strtotime($content['scheduled_at']));
    $byDate[$dateKey][] = $content;
}

$firstWeekday = (int) $monthStart->format('N'); // 1 Monday - 7 Sunday
$daysInMonth = (int) $monthStart->format('t');
$weeks = [];
$week = array_fill(0, 7, null);
$cellIndex = $firstWeekday - 1;
for ($day = 1; $day <= $daysInMonth; $day++) {
    $week[$cellIndex] = $day;
    $cellIndex++;
    if ($cellIndex === 7) {
        $weeks[] = $week;
        $week = array_fill(0, 7, null);
        $cellIndex = 0;
    }
}
if (array_filter($week, fn($v) => $v !== null)) {
    $weeks[] = $week;
}

$monthNames = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
$monthTitle = $monthNames[(int) $monthStart->format('n')] . ' ' . $monthStart->format('Y');

require BASE_PATH . '/includes/header.php';
?>

<div class="page-actions calendar-actions">
    <div class="calendar-nav">
        <a class="btn btn-ghost" href="calendar.php?month=<?= e($prevMonth) ?>">←</a>
        <h2><?= e($monthTitle) ?></h2>
        <a class="btn btn-ghost" href="calendar.php?month=<?= e($nextMonth) ?>">→</a>
        <a class="btn btn-secondary" href="calendar.php?month=<?= e(date('Y-m')) ?>">Bulan Ini</a>
    </div>
    <?php if (can_edit_content()): ?><a class="btn btn-primary" href="content_form.php">+ Jadwalkan Konten</a><?php endif; ?>
</div>

<section class="panel calendar-panel">
    <div class="calendar-legend">
        <span><i class="platform-dot instagram"></i>Instagram</span>
        <span><i class="platform-dot tiktok"></i>TikTok</span>
        <span><i class="platform-dot youtube"></i>YouTube</span>
        <span><i class="platform-dot facebook"></i>Facebook</span>
        <span><i class="platform-dot website"></i>Website</span>
    </div>
    <div class="calendar-wrap">
        <div class="calendar-grid calendar-head">
            <?php foreach (['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'] as $dayName): ?>
                <div><?= e($dayName) ?></div>
            <?php endforeach; ?>
        </div>
        <div class="calendar-body">
            <?php foreach ($weeks as $week): ?>
                <div class="calendar-grid calendar-week">
                    <?php foreach ($week as $day): ?>
                        <?php if ($day === null): ?>
                            <div class="calendar-cell is-empty"></div>
                        <?php else: ?>
                            <?php $dateKey = $monthStart->format('Y-m-') . str_pad((string) $day, 2, '0', STR_PAD_LEFT); ?>
                            <div class="calendar-cell <?= $dateKey === date('Y-m-d') ? 'is-today' : '' ?>">
                                <div class="calendar-day-number"><span><?= $day ?></span><?php if ($dateKey === date('Y-m-d')): ?><small>Hari ini</small><?php endif; ?></div>
                                <div class="calendar-events">
                                    <?php foreach ($byDate[$dateKey] ?? [] as $content): ?>
                                        <a class="calendar-event event-<?= e(strtolower($content['platform'])) ?>" href="content_detail.php?id=<?= (int) $content['id'] ?>" title="<?= e($content['title']) ?>">
                                            <span><?= e(format_date($content['scheduled_at'], 'H:i')) ?></span>
                                            <strong><?= e($content['title']) ?></strong>
                                            <small><?= e($content['content_format']) ?> · <?= e($content['status']) ?></small>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="panel mobile-calendar-list">
    <div class="panel-header"><div><h2>Agenda <?= e($monthTitle) ?></h2><p><?= count($contents) ?> konten terjadwal.</p></div></div>
    <div class="timeline-list">
        <?php if (!$contents): ?><div class="empty-state">Belum ada jadwal pada bulan ini.</div><?php endif; ?>
        <?php foreach ($contents as $content): ?>
            <a class="timeline-item" href="content_detail.php?id=<?= (int) $content['id'] ?>">
                <div class="date-box"><strong><?= e(format_date($content['scheduled_at'], 'd')) ?></strong><span><?= e(strtoupper(format_date($content['scheduled_at'], 'M'))) ?></span></div>
                <div class="timeline-copy"><strong><?= e($content['title']) ?></strong><span><?= e($content['platform']) ?> · <?= e($content['content_format']) ?> · <?= e(format_date($content['scheduled_at'], 'H:i')) ?> WIB</span></div>
                <span class="badge badge-<?= e(status_class($content['status'])) ?>"><?= e($content['status']) ?></span>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>
