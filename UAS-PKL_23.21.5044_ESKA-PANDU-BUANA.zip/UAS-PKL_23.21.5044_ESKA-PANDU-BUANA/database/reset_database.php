<?php
// Jalankan dari terminal: php database/reset_database.php
$db = __DIR__ . '/../storage/content_planner.sqlite';
if (file_exists($db)) {
    unlink($db);
    echo "Database lama dihapus.\n";
}
require __DIR__ . '/../bootstrap.php';
echo "Database baru berhasil dibuat dari database/schema.sql.\n";
