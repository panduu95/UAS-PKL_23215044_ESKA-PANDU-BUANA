<?php
require __DIR__ . '/bootstrap.php';
require_login();

$pageTitle = 'Ide Konten';
$activePage = 'ideas';
$canEdit = can_edit_content();

if (is_post()) {
    verify_csrf();
    $action = $_POST['action'] ?? 'save';

    if (!$canEdit) {
        http_response_code(403);
        exit('Akses ditolak.');
    }

    if ($action === 'delete') {
        require_role('admin');
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = $pdo->prepare('DELETE FROM content_ideas WHERE id = ?');
        $stmt->execute([$id]);
        flash('success', 'Ide konten berhasil dihapus.');
        redirect('ideas.php');
    }

    $id = (int) ($_POST['id'] ?? 0);
    $title = trim((string) ($_POST['title'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    $category = trim((string) ($_POST['category'] ?? 'Informasi'));
    $status = (string) ($_POST['status'] ?? 'New');
    $allowedStatus = ['New', 'Approved', 'Archived'];

    if ($title === '') {
        flash('danger', 'Judul ide wajib diisi.');
        redirect($id ? 'ideas.php?edit=' . $id : 'ideas.php');
    }
    if (!in_array($status, $allowedStatus, true)) {
        $status = 'New';
    }

    if ($id > 0) {
        $stmt = $pdo->prepare('UPDATE content_ideas SET title = ?, description = ?, category = ?, status = ? WHERE id = ?');
        $stmt->execute([$title, $description, $category, $status, $id]);
        flash('success', 'Ide konten berhasil diperbarui.');
    } else {
        $stmt = $pdo->prepare('INSERT INTO content_ideas (title, description, category, proposer_id, status) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$title, $description, $category, current_user()['id'], $status]);
        flash('success', 'Ide konten baru berhasil ditambahkan.');
    }
    redirect('ideas.php');
}

$editIdea = null;
if ($canEdit && isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM content_ideas WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editIdea = $stmt->fetch() ?: null;
}

$search = trim((string) ($_GET['q'] ?? ''));
$statusFilter = trim((string) ($_GET['status'] ?? ''));
$sql = 'SELECT i.*, u.name AS proposer_name FROM content_ideas i LEFT JOIN users u ON u.id = i.proposer_id WHERE 1=1';
$params = [];
if ($search !== '') {
    $sql .= ' AND (i.title LIKE ? OR i.description LIKE ? OR i.category LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
if ($statusFilter !== '') {
    $sql .= ' AND i.status = ?';
    $params[] = $statusFilter;
}
$sql .= ' ORDER BY datetime(i.created_at) DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$ideas = $stmt->fetchAll();

$categories = ['Informasi', 'Promosi', 'Edukasi', 'Kegiatan Sekolah', 'Kegiatan Siswa', 'Prestasi', 'Penerimaan Siswa Baru', 'Lainnya'];

require BASE_PATH . '/includes/header.php';
?>

<div class="page-actions">
    <form class="filter-bar" method="get">
        <input type="search" name="q" value="<?= e($search) ?>" placeholder="Cari judul, deskripsi, atau kategori…">
        <select name="status">
            <option value="">Semua status</option>
            <?php foreach (['New', 'Approved', 'Archived'] as $option): ?>
                <option value="<?= e($option) ?>" <?= selected($statusFilter, $option) ?>><?= e($option) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-secondary" type="submit">Terapkan</button>
        <?php if ($search || $statusFilter): ?><a class="btn btn-ghost" href="ideas.php">Reset</a><?php endif; ?>
    </form>
    <?php if ($canEdit): ?>
        <a class="btn btn-primary" href="#idea-form">+ Tambah Ide</a>
    <?php endif; ?>
</div>

<div class="layout-split <?= !$canEdit ? 'layout-single' : '' ?>">
    <section class="panel">
        <div class="panel-header">
            <div><h2>Bank Ide Konten</h2><p><?= count($ideas) ?> ide ditemukan.</p></div>
        </div>
        <div class="idea-grid">
            <?php if (!$ideas): ?>
                <div class="empty-state full-span">Belum ada ide yang sesuai dengan filter.</div>
            <?php endif; ?>
            <?php foreach ($ideas as $idea): ?>
                <article class="idea-card">
                    <div class="idea-card-top">
                        <span class="category-chip"><?= e($idea['category']) ?></span>
                        <span class="badge badge-<?= e(status_class($idea['status'])) ?>"><?= e($idea['status']) ?></span>
                    </div>
                    <h3><?= e($idea['title']) ?></h3>
                    <p><?= e(excerpt($idea['description'], 130)) ?></p>
                    <div class="idea-card-meta">
                        <span>Oleh <?= e($idea['proposer_name'] ?: 'Pengguna') ?></span>
                        <span><?= e(format_date($idea['created_at'])) ?></span>
                    </div>
                    <?php if ($canEdit): ?>
                        <div class="card-actions">
                            <a class="btn btn-small btn-secondary" href="ideas.php?edit=<?= (int) $idea['id'] ?>#idea-form">Edit</a>
                            <?php if (can_manage()): ?>
                                <form method="post" data-confirm="Hapus ide ini secara permanen?">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= (int) $idea['id'] ?>">
                                    <button class="btn btn-small btn-danger-ghost" type="submit">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if ($canEdit): ?>
    <aside class="panel form-panel" id="idea-form">
        <div class="panel-header">
            <div>
                <h2><?= $editIdea ? 'Edit Ide Konten' : 'Tambah Ide Baru' ?></h2>
                <p>Catat ide agar tidak tercecer dan mudah ditindaklanjuti.</p>
            </div>
            <?php if ($editIdea): ?><a class="text-link" href="ideas.php#idea-form">Batal</a><?php endif; ?>
        </div>
        <form method="post" class="stack-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($editIdea['id'] ?? 0) ?>">
            <label><span>Judul ide *</span><input type="text" name="title" maxlength="150" required value="<?= e($editIdea['title'] ?? '') ?>" placeholder="Contoh: Profil Jurusan TJKT"></label>
            <label><span>Deskripsi</span><textarea name="description" rows="5" placeholder="Jelaskan konsep, tujuan, dan bahan yang dibutuhkan."><?= e($editIdea['description'] ?? '') ?></textarea></label>
            <label><span>Kategori</span>
                <select name="category">
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= e($category) ?>" <?= selected($editIdea['category'] ?? 'Informasi', $category) ?>><?= e($category) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label><span>Status</span>
                <select name="status">
                    <?php foreach (['New', 'Approved', 'Archived'] as $option): ?>
                        <option value="<?= e($option) ?>" <?= selected($editIdea['status'] ?? 'New', $option) ?>><?= e($option) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <button class="btn btn-primary btn-block" type="submit"><?= $editIdea ? 'Simpan Perubahan' : 'Tambahkan Ide' ?></button>
        </form>
    </aside>
    <?php endif; ?>
</div>

<?php require BASE_PATH . '/includes/footer.php'; ?>
