<?php
$pageTitle = $pageTitle ?? 'Beranda';
$activePage = $activePage ?? '';
$user = current_user();
$flashes = pull_flashes();
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#173f72">
    <title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar" id="sidebar">
        <a class="brand" href="dashboard.php">
            <span class="brand-mark">KP</span>
            <span>
                <strong>Konten Planner</strong>
                <small>SMK Bhakti Praja</small>
            </span>
        </a>

        <nav class="nav-menu" aria-label="Menu utama">
            <a class="nav-link <?= $activePage === 'dashboard' ? 'active' : '' ?>" href="dashboard.php"><span>▦</span> Dashboard</a>
            <a class="nav-link <?= $activePage === 'ideas' ? 'active' : '' ?>" href="ideas.php"><span>✦</span> Ide Konten</a>
            <a class="nav-link <?= $activePage === 'contents' ? 'active' : '' ?>" href="contents.php"><span>▤</span> Data Konten</a>
            <a class="nav-link <?= $activePage === 'calendar' ? 'active' : '' ?>" href="calendar.php"><span>□</span> Kalender</a>
            <a class="nav-link <?= $activePage === 'tasks' ? 'active' : '' ?>" href="tasks.php"><span>✓</span> Manajemen Tugas</a>
            <a class="nav-link <?= $activePage === 'engagement' ? 'active' : '' ?>" href="engagement.php"><span>↗</span> Engagement</a>
            <a class="nav-link <?= $activePage === 'reports' ? 'active' : '' ?>" href="reports.php"><span>≋</span> Laporan</a>
            <?php if (can_manage()): ?>
                <a class="nav-link <?= $activePage === 'users' ? 'active' : '' ?>" href="users.php"><span>♙</span> Pengguna</a>
            <?php endif; ?>
        </nav>

        <div class="sidebar-footer">
            <div class="user-mini">
                <div class="avatar"><?= e(strtoupper(mb_substr($user['name'], 0, 1))) ?></div>
                <div>
                    <strong><?= e($user['name']) ?></strong>
                    <small><?= e(role_label($user['role'])) ?></small>
                </div>
            </div>
            <a class="logout-link" href="logout.php">Keluar</a>
        </div>
    </aside>

    <div class="main-area">
        <header class="topbar">
            <button class="menu-toggle" type="button" data-toggle-sidebar aria-label="Buka menu">☰</button>
            <div>
                <h1><?= e($pageTitle) ?></h1>
                <p>Pengelolaan media sosial yang terencana, terkoordinasi, dan berbasis data.</p>
            </div>
            <div class="topbar-date"><?= e(date('d M Y')) ?></div>
        </header>

        <main class="content-area">
            <?php foreach ($flashes as $flash): ?>
                <div class="alert alert-<?= e($flash['type']) ?>" data-auto-dismiss>
                    <span><?= e($flash['message']) ?></span>
                    <button type="button" aria-label="Tutup" data-dismiss-alert>×</button>
                </div>
            <?php endforeach; ?>
