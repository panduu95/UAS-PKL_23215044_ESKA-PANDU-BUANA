<?php
require __DIR__ . '/bootstrap.php';
require_login();

$pageTitle = 'Manajemen Tugas';
$activePage = 'tasks';
$user = current_user();

if (is_post()) {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'status') {
        $id = (int) ($_POST['id'] ?? 0);
        $status = (string) ($_POST['status'] ?? 'To Do');
        $allowed = ['To Do', 'On Progress', 'Review', 'Done'];
        if (!in_array($status, $allowed, true)) {
            flash('danger', 'Status tugas tidak valid.');
            redirect('tasks.php');
        }

        $stmt = $pdo->prepare('SELECT assigned_user_id FROM tasks WHERE id = ?');
        $stmt->execute([$id]);
        $task = $stmt->fetch();
        if (!$task || ($user['role'] === 'team' && (int) $task['assigned_user_id'] !== (int) $user['id']) || $user['role'] === 'humas') {
            http_response_code(403);
            exit('Akses ditolak.');
        }

        $stmt = $pdo->prepare('UPDATE tasks SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
        $stmt->execute([$status, $id]);
        flash('success', 'Status tugas berhasil diperbarui.');
        redirect('tasks.php');
    }

    require_role('admin');

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = $pdo->prepare('DELETE FROM tasks WHERE id = ?');
        $stmt->execute([$id]);
        flash('success', 'Tugas berhasil dihapus.');
        redirect('tasks.php');
    }

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $contentId = (int) ($_POST['content_id'] ?? 0);
        $assignee = (int) ($_POST['assigned_user_id'] ?? 0) ?: null;
        $description = trim((string) ($_POST['description'] ?? ''));
        $deadline = trim((string) ($_POST['deadline'] ?? '')) ?: null;
        $status = (string) ($_POST['status'] ?? 'To Do');
        $allowed = ['To Do', 'On Progress', 'Review', 'Done'];

        if ($contentId <= 0 || $description === '') {
            flash('danger', 'Konten dan deskripsi tugas wajib diisi.');
            redirect($id ? 'tasks.php?edit=' . $id . '#task-form' : 'tasks.php#task-form');
        }
        if (!in_array($status, $allowed, true)) {
            $status = 'To Do';
        }

        if ($id > 0) {
            $stmt = $pdo->prepare('UPDATE tasks SET content_id = ?, assigned_user_id = ?, description = ?, deadline = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
            $stmt->execute([$contentId, $assignee, $description, $deadline, $status, $id]);
            flash('success', 'Tugas berhasil diperbarui.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO tasks (content_id, assigned_user_id, description, deadline, status, created_by) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->execute([$contentId, $assignee, $description, $deadline, $status, $user['id']]);
            flash('success', 'Tugas baru berhasil ditambahkan.');
        }
        redirect('tasks.php');
    }
}

$editTask = null;
if (can_manage() && isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM tasks WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editTask = $stmt->fetch() ?: null;
}

$contentFilter = (int) ($_GET['content_id'] ?? 0);
$statusFilter = trim((string) ($_GET['status'] ?? ''));
$assigneeFilter = (int) ($_GET['assignee'] ?? 0);

$sql = "SELECT t.*, c.title AS content_title, c.platform, u.name AS assignee_name
        FROM tasks t
        JOIN contents c ON c.id = t.content_id
        LEFT JOIN users u ON u.id = t.assigned_user_id
        WHERE 1=1";
$params = [];
if ($user['role'] === 'team') {
    $sql .= ' AND t.assigned_user_id = ?';
    $params[] = $user['id'];
}
if ($contentFilter > 0) {
    $sql .= ' AND t.content_id = ?';
    $params[] = $contentFilter;
}
if ($statusFilter !== '') {
    $sql .= ' AND t.status = ?';
    $params[] = $statusFilter;
}
if ($assigneeFilter > 0 && $user['role'] !== 'team') {
    $sql .= ' AND t.assigned_user_id = ?';
    $params[] = $assigneeFilter;
}
$sql .= " ORDER BY CASE t.status WHEN 'Review' THEN 1 WHEN 'On Progress' THEN 2 WHEN 'To Do' THEN 3 ELSE 4 END,
          CASE WHEN t.deadline IS NULL THEN 1 ELSE 0 END,
          datetime(t.deadline) ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tasks = $stmt->fetchAll();

$contents = $pdo->query("SELECT id, title FROM contents WHERE status != 'Archived' ORDER BY title")->fetchAll();
$users = $pdo->query("SELECT id, name, role FROM users WHERE role IN ('admin', 'team') ORDER BY name")->fetchAll();

$summary = ['To Do' => 0, 'On Progress' => 0, 'Review' => 0, 'Done' => 0];
foreach ($tasks as $task) {
    if (isset($summary[$task['status']])) {
        $summary[$task['status']]++;
    }
}

require BASE_PATH . '/includes/header.php';
?>

<section class="stats-grid stats-grid-compact">
    <?php foreach ($summary as $label => $count): ?>
        <article class="mini-stat"><span><?= e($label) ?></span><strong><?= $count ?></strong></article>
    <?php endforeach; ?>
</section>

<div class="page-actions">
    <form class="filter-bar" method="get">
        <select name="content_id">
            <option value="">Semua konten</option>
            <?php foreach ($contents as $item): ?>
                <option value="<?= (int) $item['id'] ?>" <?= selected($contentFilter, $item['id']) ?>><?= e($item['title']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="status">
            <option value="">Semua status</option>
            <?php foreach (['To Do', 'On Progress', 'Review', 'Done'] as $item): ?>
                <option value="<?= e($item) ?>" <?= selected($statusFilter, $item) ?>><?= e($item) ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ($user['role'] !== 'team'): ?>
            <select name="assignee">
                <option value="">Semua penanggung jawab</option>
                <?php foreach ($users as $item): ?>
                    <option value="<?= (int) $item['id'] ?>" <?= selected($assigneeFilter, $item['id']) ?>><?= e($item['name']) ?></option>
                <?php endforeach; ?>
            </select>
        <?php endif; ?>
        <button class="btn btn-secondary" type="submit">Terapkan</button>
        <?php if ($contentFilter || $statusFilter || $assigneeFilter): ?><a class="btn btn-ghost" href="tasks.php">Reset</a><?php endif; ?>
    </form>
    <?php if (can_manage()): ?><a class="btn btn-primary" href="#task-form">+ Tambah Tugas</a><?php endif; ?>
</div>

<div class="layout-split <?= !can_manage() ? 'layout-single' : '' ?>">
    <section class="panel">
        <div class="panel-header"><div><h2>Daftar Tugas</h2><p><?= count($tasks) ?> tugas ditemukan.</p></div></div>
        <div class="task-board-list">
            <?php if (!$tasks): ?><div class="empty-state">Belum ada tugas yang sesuai dengan filter.</div><?php endif; ?>
            <?php foreach ($tasks as $task): ?>
                <article class="task-board-item">
                    <div class="task-board-main">
                        <div class="task-board-top">
                            <span class="platform-pill platform-<?= e(strtolower($task['platform'])) ?>"><?= e($task['platform']) ?></span>
                            <span class="badge badge-<?= e(status_class($task['status'])) ?>"><?= e($task['status']) ?></span>
                        </div>
                        <h3><?= e($task['description']) ?></h3>
                        <a href="content_detail.php?id=<?= (int) $task['content_id'] ?>"><?= e($task['content_title']) ?></a>
                        <div class="task-board-meta">
                            <span>♙ <?= e($task['assignee_name'] ?: 'Belum ditugaskan') ?></span>
                            <span>◷ <?= e(format_datetime($task['deadline'])) ?> WIB</span>
                        </div>
                    </div>
                    <div class="task-board-actions">
                        <?php if ($user['role'] !== 'humas' && ($user['role'] === 'admin' || (int) $task['assigned_user_id'] === (int) $user['id'])): ?>
                            <form method="post" class="status-inline-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="status">
                                <input type="hidden" name="id" value="<?= (int) $task['id'] ?>">
                                <select name="status" onchange="this.form.submit()" aria-label="Ubah status tugas">
                                    <?php foreach (['To Do', 'On Progress', 'Review', 'Done'] as $option): ?>
                                        <option value="<?= e($option) ?>" <?= selected($task['status'], $option) ?>><?= e($option) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </form>
                        <?php endif; ?>
                        <?php if (can_manage()): ?>
                            <a class="btn btn-small btn-secondary" href="tasks.php?edit=<?= (int) $task['id'] ?>#task-form">Edit</a>
                            <form method="post" data-confirm="Hapus tugas ini?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int) $task['id'] ?>">
                                <button class="btn btn-small btn-danger-ghost" type="submit">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if (can_manage()): ?>
        <aside class="panel form-panel" id="task-form">
            <div class="panel-header">
                <div><h2><?= $editTask ? 'Edit Tugas' : 'Tambah Tugas' ?></h2><p>Tentukan pekerjaan, penanggung jawab, dan tenggat.</p></div>
                <?php if ($editTask): ?><a class="text-link" href="tasks.php#task-form">Batal</a><?php endif; ?>
            </div>
            <form method="post" class="stack-form">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="id" value="<?= (int) ($editTask['id'] ?? 0) ?>">
                <label><span>Konten *</span>
                    <select name="content_id" required>
                        <option value="">Pilih konten</option>
                        <?php foreach ($contents as $item): ?>
                            <?php $defaultContent = $editTask['content_id'] ?? $contentFilter; ?>
                            <option value="<?= (int) $item['id'] ?>" <?= selected($defaultContent, $item['id']) ?>><?= e($item['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label><span>Deskripsi tugas *</span><textarea name="description" rows="5" required placeholder="Contoh: Edit video vertikal 45–60 detik."><?= e($editTask['description'] ?? '') ?></textarea></label>
                <label><span>Penanggung jawab</span>
                    <select name="assigned_user_id">
                        <option value="">Belum ditentukan</option>
                        <?php foreach ($users as $item): ?>
                            <option value="<?= (int) $item['id'] ?>" <?= selected($editTask['assigned_user_id'] ?? '', $item['id']) ?>><?= e($item['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label><span>Tenggat</span><input type="datetime-local" name="deadline" value="<?= e(isset($editTask['deadline']) && $editTask['deadline'] ? date('Y-m-d\TH:i', strtotime($editTask['deadline'])) : '') ?>"></label>
                <label><span>Status</span>
                    <select name="status">
                        <?php foreach (['To Do', 'On Progress', 'Review', 'Done'] as $option): ?>
                            <option value="<?= e($option) ?>" <?= selected($editTask['status'] ?? 'To Do', $option) ?>><?= e($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button class="btn btn-primary btn-block" type="submit"><?= $editTask ? 'Simpan Perubahan' : 'Tambahkan Tugas' ?></button>
            </form>
        </aside>
    <?php endif; ?>
</div>

<?php require BASE_PATH . '/includes/footer.php'; ?>
