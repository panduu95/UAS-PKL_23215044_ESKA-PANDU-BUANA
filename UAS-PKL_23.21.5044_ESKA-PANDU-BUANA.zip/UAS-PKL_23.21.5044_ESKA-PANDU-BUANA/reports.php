<?php
require __DIR__ . '/bootstrap.php';
require_login();

$pageTitle = 'Laporan';
$activePage = 'reports';

$startDate = (string) ($_GET['start'] ?? date('Y-m-01', strtotime('-1 month')));
$endDate = (string) ($_GET['end'] ?? date('Y-m-t'));
$platform = trim((string) ($_GET['platform'] ?? ''));

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate)) {
    $startDate = date('Y-m-01');
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate)) {
    $endDate = date('Y-m-t');
}

$sql = "SELECT c.id, c.title, c.category, c.platform, c.content_format, c.scheduled_at, c.status,
        COALESCE(e.views, 0) AS views,
        COALESCE(e.likes, 0) AS likes,
        COALESCE(e.comments, 0) AS comments,
        COALESCE(e.shares, 0) AS shares,
        COALESCE(e.reach, 0) AS reach,
        COALESCE(e.saves, 0) AS saves,
        COALESCE(e.likes + e.comments + e.shares + e.saves, 0) AS interactions
        FROM contents c
        LEFT JOIN engagements e ON e.content_id = c.id
        WHERE date(COALESCE(c.scheduled_at, c.created_at)) BETWEEN ? AND ?";
$params = [$startDate, $endDate];
if ($platform !== '') {
    $sql .= ' AND c.platform = ?';
    $params[] = $platform;
}
$sql .= ' ORDER BY datetime(COALESCE(c.scheduled_at, c.created_at)) DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

if (($_GET['export'] ?? '') === 'csv') {
    $filename = 'laporan_konten_' . $startDate . '_sampai_' . $endDate . '.csv';
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Judul', 'Kategori', 'Platform', 'Format', 'Jadwal', 'Status', 'Views', 'Reach', 'Likes', 'Komentar', 'Shares', 'Saves', 'Total Interaksi'], ';', chr(34), '');
    foreach ($rows as $row) {
        fputcsv($out, [
            $row['title'], $row['category'], $row['platform'], $row['content_format'], $row['scheduled_at'], $row['status'],
            $row['views'], $row['reach'], $row['likes'], $row['comments'], $row['shares'], $row['saves'], $row['interactions']
        ], ';', chr(34), '');
    }
    fclose($out);
    exit;
}

$summary = [
    'total_contents' => count($rows),
    'published' => 0,
    'views' => 0,
    'reach' => 0,
    'interactions' => 0,
];
$platformSummary = [];
$statusSummary = ['To Do' => 0, 'On Progress' => 0, 'Review' => 0, 'Published' => 0, 'Archived' => 0];
foreach ($rows as $row) {
    if ($row['status'] === 'Published') {
        $summary['published']++;
    }
    $summary['views'] += (int) $row['views'];
    $summary['reach'] += (int) $row['reach'];
    $summary['interactions'] += (int) $row['interactions'];
    $statusSummary[$row['status']] = ($statusSummary[$row['status']] ?? 0) + 1;
    if (!isset($platformSummary[$row['platform']])) {
        $platformSummary[$row['platform']] = ['contents' => 0, 'views' => 0, 'reach' => 0, 'interactions' => 0];
    }
    $platformSummary[$row['platform']]['contents']++;
    $platformSummary[$row['platform']]['views'] += (int) $row['views'];
    $platformSummary[$row['platform']]['reach'] += (int) $row['reach'];
    $platformSummary[$row['platform']]['interactions'] += (int) $row['interactions'];
}

$topRows = $rows;
usort($topRows, fn(array $a, array $b): int => ((int) $b['interactions'] <=> (int) $a['interactions']) ?: ((int) $b['views'] <=> (int) $a['views']));
$topRows = array_slice($topRows, 0, 5);

$platforms = ['Instagram', 'TikTok', 'YouTube', 'Facebook', 'Website'];
$query = http_build_query(['start' => $startDate, 'end' => $endDate, 'platform' => $platform, 'export' => 'csv']);

require BASE_PATH . '/includes/header.php';
?>

<div class="page-actions">
    <form class="filter-bar report-filter" method="get">
        <label><span>Dari</span><input type="date" name="start" value="<?= e($startDate) ?>"></label>
        <label><span>Sampai</span><input type="date" name="end" value="<?= e($endDate) ?>"></label>
        <label><span>Platform</span>
            <select name="platform">
                <option value="">Semua platform</option>
                <?php foreach ($platforms as $item): ?>
                    <option value="<?= e($item) ?>" <?= selected($platform, $item) ?>><?= e($item) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <button class="btn btn-secondary" type="submit">Tampilkan</button>
    </form>
    <a class="btn btn-primary" href="reports.php?<?= e($query) ?>">↓ Unduh CSV</a>
</div>

<section class="stats-grid">
    <article class="stat-card"><div class="stat-icon">▤</div><div><span>Total Konten</span><strong><?= $summary['total_contents'] ?></strong><small><?= $summary['published'] ?> sudah dipublikasikan</small></div></article>
    <article class="stat-card"><div class="stat-icon">◉</div><div><span>Total Views</span><strong><?= number_format($summary['views'], 0, ',', '.') ?></strong><small>Dalam periode terpilih</small></div></article>
    <article class="stat-card"><div class="stat-icon">◎</div><div><span>Total Reach</span><strong><?= number_format($summary['reach'], 0, ',', '.') ?></strong><small>Jangkauan audiens</small></div></article>
    <article class="stat-card"><div class="stat-icon">↗</div><div><span>Total Interaksi</span><strong><?= number_format($summary['interactions'], 0, ',', '.') ?></strong><small>Likes, komentar, share, save</small></div></article>
</section>

<section class="dashboard-grid">
    <article class="panel">
        <div class="panel-header"><div><h2>Ringkasan per Platform</h2><p>Perbandingan jumlah konten dan performa tiap platform.</p></div></div>
        <div class="platform-report-list">
            <?php if (!$platformSummary): ?><div class="empty-state">Belum ada data pada periode ini.</div><?php endif; ?>
            <?php foreach ($platformSummary as $name => $data): ?>
                <div class="platform-report-item">
                    <div><span class="platform-pill platform-<?= e(strtolower($name)) ?>"><?= e($name) ?></span><strong><?= $data['contents'] ?> konten</strong></div>
                    <div><span>Views</span><strong><?= number_format($data['views'], 0, ',', '.') ?></strong></div>
                    <div><span>Reach</span><strong><?= number_format($data['reach'], 0, ',', '.') ?></strong></div>
                    <div><span>Interaksi</span><strong><?= number_format($data['interactions'], 0, ',', '.') ?></strong></div>
                </div>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="panel">
        <div class="panel-header"><div><h2>Komposisi Status</h2><p>Distribusi progres konten dalam periode laporan.</p></div></div>
        <div class="status-progress-list">
            <?php foreach ($statusSummary as $label => $count): ?>
                <?php $percent = $summary['total_contents'] > 0 ? ($count / $summary['total_contents']) * 100 : 0; ?>
                <div class="status-progress-item">
                    <div><span><?= e($label) ?></span><strong><?= $count ?></strong></div>
                    <div class="progress-track"><span style="width: <?= e((string) $percent) ?>%"></span></div>
                </div>
            <?php endforeach; ?>
        </div>
    </article>
</section>

<section class="panel">
    <div class="panel-header"><div><h2>Konten dengan Performa Terbaik</h2><p>Diurutkan berdasarkan total interaksi, lalu jumlah views.</p></div></div>
    <div class="top-content-grid">
        <?php if (!$topRows): ?><div class="empty-state full-span">Belum ada data pada periode ini.</div><?php endif; ?>
        <?php foreach ($topRows as $index => $row): ?>
            <a class="top-content-card" href="content_detail.php?id=<?= (int) $row['id'] ?>">
                <span class="rank-badge">#<?= $index + 1 ?></span>
                <span class="platform-pill platform-<?= e(strtolower($row['platform'])) ?>"><?= e($row['platform']) ?></span>
                <h3><?= e($row['title']) ?></h3>
                <div class="top-content-metrics">
                    <div><span>Views</span><strong><?= number_format((int) $row['views'], 0, ',', '.') ?></strong></div>
                    <div><span>Reach</span><strong><?= number_format((int) $row['reach'], 0, ',', '.') ?></strong></div>
                    <div><span>Interaksi</span><strong><?= number_format((int) $row['interactions'], 0, ',', '.') ?></strong></div>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<section class="panel">
    <div class="panel-header"><div><h2>Rekap Detail</h2><p>Periode <?= e(format_date($startDate)) ?> sampai <?= e(format_date($endDate)) ?>.</p></div></div>
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>Konten</th><th>Jadwal</th><th>Status</th><th>Views</th><th>Reach</th><th>Interaksi</th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="6"><div class="empty-state">Belum ada data pada periode ini.</div></td></tr><?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td><a class="table-title" href="content_detail.php?id=<?= (int) $row['id'] ?>"><?= e($row['title']) ?></a><span class="table-subtitle"><?= e($row['platform']) ?> · <?= e($row['content_format']) ?></span></td>
                    <td><?= e(format_datetime($row['scheduled_at'])) ?></td>
                    <td><span class="badge badge-<?= e(status_class($row['status'])) ?>"><?= e($row['status']) ?></span></td>
                    <td><?= number_format((int) $row['views'], 0, ',', '.') ?></td>
                    <td><?= number_format((int) $row['reach'], 0, ',', '.') ?></td>
                    <td><strong><?= number_format((int) $row['interactions'], 0, ',', '.') ?></strong></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>
