<?php
require __DIR__ . '/bootstrap.php';

$_SESSION = [];
session_regenerate_id(true);
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
flash('success', 'Anda berhasil keluar dari sistem.');
redirect('login.php');
