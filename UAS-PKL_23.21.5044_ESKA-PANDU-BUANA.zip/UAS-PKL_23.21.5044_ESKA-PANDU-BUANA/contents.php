<?php
require __DIR__ . '/bootstrap.php';
require_login();

$pageTitle = 'Data Konten';
$activePage = 'contents';

if (is_post()) {
    verify_csrf();
    require_role('admin');
    if (($_POST['action'] ?? '') === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = $pdo->prepare('DELETE FROM contents WHERE id = ?');
        $stmt->execute([$id]);
        flash('success', 'Konten beserta data terkait berhasil dihapus.');
        redirect('contents.php');
    }
}

$q = trim((string) ($_GET['q'] ?? ''));
$status = trim((string) ($_GET['status'] ?? ''));
$platform = trim((string) ($_GET['platform'] ?? ''));

$sql = "SELECT c.*, u.name AS assignee_name,
    COALESCE(e.views, 0) AS views,
    COALESCE(e.likes, 0) AS likes
    FROM contents c
    LEFT JOIN users u ON u.id = c.assigned_user_id
    LEFT JOIN engagements e ON e.content_id = c.id
    WHERE 1=1";
$params = [];
if ($q !== '') {
    $sql .= ' AND (c.title LIKE ? OR c.caption LIKE ? OR c.category LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like);
}
if ($status !== '') {
    $sql .= ' AND c.status = ?';
    $params[] = $status;
}
if ($platform !== '') {
    $sql .= ' AND c.platform = ?';
    $params[] = $platform;
}
$sql .= " ORDER BY CASE c.status WHEN 'Review' THEN 1 WHEN 'On Progress' THEN 2 WHEN 'To Do' THEN 3 WHEN 'Published' THEN 4 ELSE 5 END, datetime(c.scheduled_at) ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$contents = $stmt->fetchAll();

$statuses = ['To Do', 'On Progress', 'Review', 'Published', 'Archived'];
$platforms = ['Instagram', 'TikTok', 'YouTube', 'Facebook', 'Website'];

require BASE_PATH . '/includes/header.php';
?>

<div class="page-actions">
    <form class="filter-bar" method="get">
        <input type="search" name="q" value="<?= e($q) ?>" placeholder="Cari judul, caption, kategori…">
        <select name="status">
            <option value="">Semua status</option>
            <?php foreach ($statuses as $item): ?>
                <option value="<?= e($item) ?>" <?= selected($status, $item) ?>><?= e($item) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="platform">
            <option value="">Semua platform</option>
            <?php foreach ($platforms as $item): ?>
                <option value="<?= e($item) ?>" <?= selected($platform, $item) ?>><?= e($item) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-secondary" type="submit">Terapkan</button>
        <?php if ($q || $status || $platform): ?><a class="btn btn-ghost" href="contents.php">Reset</a><?php endif; ?>
    </form>
    <?php if (can_edit_content()): ?>
        <a class="btn btn-primary" href="content_form.php">+ Tambah Konten</a>
    <?php endif; ?>
</div>

<section class="panel">
    <div class="panel-header">
        <div><h2>Daftar Konten</h2><p><?= count($contents) ?> konten ditemukan.</p></div>
        <div class="view-switch" aria-label="Pilihan tampilan"><button class="active" type="button">☷</button><button type="button">▦</button></div>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
            <tr>
                <th>Konten</th>
                <th>Platform</th>
                <th>Jadwal</th>
                <th>Penanggung Jawab</th>
                <th>Status</th>
                <th>Performa</th>
                <th class="text-right">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php if (!$contents): ?>
                <tr><td colspan="7"><div class="empty-state">Belum ada konten yang sesuai dengan filter.</div></td></tr>
            <?php endif; ?>
            <?php foreach ($contents as $content): ?>
                <tr>
                    <td>
                        <a class="table-title" href="content_detail.php?id=<?= (int) $content['id'] ?>"><?= e($content['title']) ?></a>
                        <span class="table-subtitle"><?= e($content['category']) ?> · <?= e($content['content_format']) ?></span>
                    </td>
                    <td><span class="platform-pill platform-<?= e(strtolower($content['platform'])) ?>"><?= e($content['platform']) ?></span></td>
                    <td>
                        <strong><?= e(format_date($content['scheduled_at'])) ?></strong>
                        <span class="table-subtitle"><?= e(format_date($content['scheduled_at'], 'H:i')) ?> WIB</span>
                    </td>
                    <td><?= e($content['assignee_name'] ?: 'Belum ditugaskan') ?></td>
                    <td><span class="badge badge-<?= e(status_class($content['status'])) ?>"><?= e($content['status']) ?></span></td>
                    <td>
                        <?php if ($content['status'] === 'Published'): ?>
                            <strong><?= number_format((int) $content['views'], 0, ',', '.') ?> views</strong>
                            <span class="table-subtitle"><?= number_format((int) $content['likes'], 0, ',', '.') ?> likes</span>
                        <?php else: ?>
                            <span class="muted">Belum tersedia</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-right">
                        <div class="inline-actions inline-actions-right">
                            <a class="btn btn-small btn-secondary" href="content_detail.php?id=<?= (int) $content['id'] ?>">Detail</a>
                            <?php if (can_edit_content()): ?><a class="btn btn-small btn-ghost" href="content_form.php?id=<?= (int) $content['id'] ?>">Edit</a><?php endif; ?>
                            <?php if (can_manage()): ?>
                                <form method="post" data-confirm="Hapus konten ini beserta tugas, file, engagement, dan feedback terkait?">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= (int) $content['id'] ?>">
                                    <button class="btn btn-small btn-danger-ghost" type="submit">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>
