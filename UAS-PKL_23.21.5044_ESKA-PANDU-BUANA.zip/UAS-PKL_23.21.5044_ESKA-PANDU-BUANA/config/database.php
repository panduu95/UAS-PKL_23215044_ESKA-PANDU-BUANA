<?php

declare(strict_types=1);

$dbPath = getenv('APP_DB_PATH') ?: BASE_PATH . '/storage/content_planner.sqlite';
$dbDir = dirname($dbPath);

if (!is_dir($dbDir)) {
    mkdir($dbDir, 0775, true);
}

$firstRun = !file_exists($dbPath) || filesize($dbPath) === 0;

try {
    $pdo = new PDO('sqlite:' . $dbPath, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec('PRAGMA foreign_keys = ON');

    if ($firstRun) {
        $schema = file_get_contents(BASE_PATH . '/database/schema.sql');
        if ($schema === false) {
            throw new RuntimeException('File database/schema.sql tidak ditemukan.');
        }
        $pdo->exec($schema);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo '<h1>Koneksi database gagal</h1>';
    echo '<p>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</p>';
    exit;
}
