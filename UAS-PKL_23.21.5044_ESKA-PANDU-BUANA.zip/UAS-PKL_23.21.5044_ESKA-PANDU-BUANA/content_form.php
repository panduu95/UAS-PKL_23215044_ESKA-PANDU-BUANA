<?php
require __DIR__ . '/bootstrap.php';
require_role(['admin', 'team']);

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$content = null;
if ($id > 0) {
    $stmt = $pdo->prepare('SELECT * FROM contents WHERE id = ?');
    $stmt->execute([$id]);
    $content = $stmt->fetch();
    if (!$content) {
        http_response_code(404);
        exit('Data konten tidak ditemukan.');
    }
}

$pageTitle = $content ? 'Edit Konten' : 'Tambah Konten';
$activePage = 'contents';

if (is_post()) {
    verify_csrf();

    $title = trim((string) ($_POST['title'] ?? ''));
    $category = trim((string) ($_POST['category'] ?? 'Informasi'));
    $platform = (string) ($_POST['platform'] ?? 'Instagram');
    $format = (string) ($_POST['content_format'] ?? 'Feed');
    $caption = trim((string) ($_POST['caption'] ?? ''));
    $scheduledAt = trim((string) ($_POST['scheduled_at'] ?? '')) ?: null;
    $status = (string) ($_POST['status'] ?? 'To Do');
    $assignee = (int) ($_POST['assigned_user_id'] ?? 0) ?: null;

    $platforms = ['Instagram', 'TikTok', 'YouTube', 'Facebook', 'Website'];
    $formats = ['Feed', 'Reels', 'Story', 'Video', 'Poster', 'Artikel'];
    $statuses = ['To Do', 'On Progress', 'Review', 'Published', 'Archived'];

    if ($title === '') {
        flash('danger', 'Judul konten wajib diisi.');
        redirect($id ? 'content_form.php?id=' . $id : 'content_form.php');
    }
    if (!in_array($platform, $platforms, true) || !in_array($format, $formats, true) || !in_array($status, $statuses, true)) {
        flash('danger', 'Pilihan platform, format, atau status tidak valid.');
        redirect($id ? 'content_form.php?id=' . $id : 'content_form.php');
    }

    if ($id > 0) {
        $stmt = $pdo->prepare('UPDATE contents SET title = ?, category = ?, platform = ?, content_format = ?, caption = ?, scheduled_at = ?, status = ?, assigned_user_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
        $stmt->execute([$title, $category, $platform, $format, $caption, $scheduledAt, $status, $assignee, $id]);
        flash('success', 'Data konten berhasil diperbarui.');
    } else {
        $stmt = $pdo->prepare('INSERT INTO contents (title, category, platform, content_format, caption, scheduled_at, status, assigned_user_id, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$title, $category, $platform, $format, $caption, $scheduledAt, $status, $assignee, current_user()['id']]);
        $id = (int) $pdo->lastInsertId();
        flash('success', 'Konten baru berhasil ditambahkan.');
    }

    if (!empty($_FILES['content_file']['name'])) {
        try {
            $uploaded = upload_file($_FILES['content_file'], $id);
            if ($uploaded) {
                $stmt = $pdo->prepare('INSERT INTO content_files (content_id, original_name, stored_name, mime_type, size_bytes, file_path, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$id, $uploaded['original_name'], $uploaded['stored_name'], $uploaded['mime_type'], $uploaded['size_bytes'], $uploaded['path'], current_user()['id']]);
                flash('success', 'File pendukung berhasil diunggah.');
            }
        } catch (RuntimeException $e) {
            flash('warning', 'Data tersimpan, tetapi file tidak terunggah: ' . $e->getMessage());
        }
    }

    redirect('content_detail.php?id=' . $id);
}

$users = $pdo->query("SELECT id, name, role FROM users WHERE role IN ('admin', 'team') ORDER BY name")->fetchAll();
$categories = ['Informasi', 'Promosi', 'Edukasi', 'Kegiatan Sekolah', 'Kegiatan Siswa', 'Prestasi', 'Penerimaan Siswa Baru', 'Lainnya'];
$platforms = ['Instagram', 'TikTok', 'YouTube', 'Facebook', 'Website'];
$formats = ['Feed', 'Reels', 'Story', 'Video', 'Poster', 'Artikel'];
$statuses = ['To Do', 'On Progress', 'Review', 'Published', 'Archived'];

require BASE_PATH . '/includes/header.php';
?>

<div class="page-actions">
    <a class="btn btn-ghost" href="<?= $content ? 'content_detail.php?id=' . (int) $content['id'] : 'contents.php' ?>">← Kembali</a>
</div>

<section class="panel form-page-panel">
    <div class="panel-header">
        <div>
            <h2><?= $content ? 'Perbarui Data Konten' : 'Buat Rencana Konten Baru' ?></h2>
            <p>Lengkapi informasi utama, jadwal, penanggung jawab, dan file pendukung.</p>
        </div>
    </div>

    <form method="post" enctype="multipart/form-data" class="form-grid">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int) ($content['id'] ?? 0) ?>">

        <label class="span-2"><span>Judul konten *</span><input type="text" name="title" required maxlength="180" value="<?= e($content['title'] ?? '') ?>" placeholder="Contoh: Video Profil Jurusan TJKT"></label>

        <label><span>Kategori</span>
            <select name="category">
                <?php foreach ($categories as $item): ?>
                    <option value="<?= e($item) ?>" <?= selected($content['category'] ?? 'Informasi', $item) ?>><?= e($item) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label><span>Platform</span>
            <select name="platform">
                <?php foreach ($platforms as $item): ?>
                    <option value="<?= e($item) ?>" <?= selected($content['platform'] ?? 'Instagram', $item) ?>><?= e($item) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label><span>Format konten</span>
            <select name="content_format">
                <?php foreach ($formats as $item): ?>
                    <option value="<?= e($item) ?>" <?= selected($content['content_format'] ?? 'Feed', $item) ?>><?= e($item) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label><span>Status pengerjaan</span>
            <select name="status">
                <?php foreach ($statuses as $item): ?>
                    <option value="<?= e($item) ?>" <?= selected($content['status'] ?? 'To Do', $item) ?>><?= e($item) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label><span>Jadwal publikasi</span><input type="datetime-local" name="scheduled_at" value="<?= e(isset($content['scheduled_at']) && $content['scheduled_at'] ? date('Y-m-d\TH:i', strtotime($content['scheduled_at'])) : '') ?>"></label>

        <label><span>Penanggung jawab</span>
            <select name="assigned_user_id">
                <option value="">Belum ditentukan</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?= (int) $user['id'] ?>" <?= selected($content['assigned_user_id'] ?? '', $user['id']) ?>><?= e($user['name']) ?> — <?= e(role_label($user['role'])) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label class="span-2"><span>Caption / naskah</span><textarea name="caption" rows="8" placeholder="Tulis caption, ajakan, hashtag, atau naskah video di sini."><?= e($content['caption'] ?? '') ?></textarea></label>

        <label class="span-2 file-drop"><span>File pendukung (opsional)</span><input type="file" name="content_file" accept="image/jpeg,image/png,image/webp,video/mp4,application/pdf"><small>Maksimal 8 MB. Format JPG, PNG, WEBP, MP4, atau PDF.</small></label>

        <div class="span-2 form-actions">
            <a class="btn btn-ghost" href="<?= $content ? 'content_detail.php?id=' . (int) $content['id'] : 'contents.php' ?>">Batal</a>
            <button class="btn btn-primary" type="submit"><?= $content ? 'Simpan Perubahan' : 'Simpan Konten' ?></button>
        </div>
    </form>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>
