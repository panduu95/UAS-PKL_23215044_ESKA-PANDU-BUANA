<?php
require __DIR__ . '/bootstrap.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

$error = '';
if (is_post()) {
    verify_csrf();
    $email = trim(strtolower((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');

    $stmt = $pdo->prepare('SELECT * FROM users WHERE lower(email) = :email LIMIT 1');
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        unset($user['password']);
        $_SESSION['user'] = $user;
        session_regenerate_id(true);
        flash('success', 'Selamat datang, ' . $user['name'] . '.');
        redirect('dashboard.php');
    }

    $error = 'Email atau kata sandi tidak sesuai.';
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masuk | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-body">
<div class="login-layout">
    <section class="login-visual">
        <div class="login-badge">CAPSTONE PROJECT PKL 2026</div>
        <div class="login-visual-content">
            <span class="brand-mark brand-mark-large">KP</span>
            <h1>Sistem Konten Planner</h1>
            <p>Membantu tim SMK Bhakti Praja Adiwerna merencanakan, memproduksi, menjadwalkan, dan mengevaluasi konten media sosial dalam satu tempat.</p>
            <div class="feature-list">
                <span>✓ Kalender publikasi</span>
                <span>✓ Pembagian tugas</span>
                <span>✓ Monitoring progres</span>
                <span>✓ Evaluasi engagement</span>
            </div>
        </div>
        <div class="login-credit">Eska Pandu Buana · 23.21.5044</div>
    </section>

    <section class="login-panel">
        <div class="login-card">
            <div class="mobile-brand">
                <span class="brand-mark">KP</span>
                <strong>Konten Planner</strong>
            </div>
            <p class="eyebrow">SELAMAT DATANG</p>
            <h2>Masuk ke sistem</h2>
            <p class="muted">Gunakan akun yang telah terdaftar untuk mengakses dashboard.</p>

            <?php if ($error): ?>
                <div class="alert alert-danger"><span><?= e($error) ?></span></div>
            <?php endif; ?>

            <form method="post" class="stack-form">
                <?= csrf_field() ?>
                <label>
                    <span>Email</span>
                    <input type="email" name="email" value="<?= e($_POST['email'] ?? 'admin@smkbpa.sch.id') ?>" required autofocus>
                </label>
                <label>
                    <span>Kata sandi</span>
                    <div class="password-wrap">
                        <input id="password" type="password" name="password" value="admin123" required>
                        <button type="button" class="password-toggle" data-toggle-password="#password">Lihat</button>
                    </div>
                </label>
                <button class="btn btn-primary btn-block" type="submit">Masuk ke Dashboard</button>
            </form>

            <div class="demo-accounts">
                <strong>Akun demo</strong>
                <div><span>Admin</span><code>admin@smkbpa.sch.id / admin123</code></div>
                <div><span>Tim</span><code>eska@smkbpa.sch.id / team123</code></div>
                <div><span>Humas</span><code>humas@smkbpa.sch.id / humas123</code></div>
            </div>
        </div>
    </section>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>
