<?php
require __DIR__ . '/bootstrap.php';
require_login();

$id = (int) ($_GET['id'] ?? $_POST['content_id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    exit('ID konten tidak valid.');
}

if (is_post()) {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'feedback') {
        $note = trim((string) ($_POST['note'] ?? ''));
        if ($note === '') {
            flash('danger', 'Catatan feedback tidak boleh kosong.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO feedbacks (content_id, note, feedback_by) VALUES (?, ?, ?)');
            $stmt->execute([$id, $note, current_user()['id']]);
            flash('success', 'Feedback berhasil ditambahkan.');
        }
        redirect('content_detail.php?id=' . $id . '#feedback');
    }

    if ($action === 'delete_file') {
        require_role(['admin', 'team']);
        $fileId = (int) ($_POST['file_id'] ?? 0);
        $stmt = $pdo->prepare('SELECT * FROM content_files WHERE id = ? AND content_id = ?');
        $stmt->execute([$fileId, $id]);
        $file = $stmt->fetch();
        if ($file) {
            $fullPath = BASE_PATH . '/' . $file['file_path'];
            if (is_file($fullPath)) {
                @unlink($fullPath);
            }
            $stmt = $pdo->prepare('DELETE FROM content_files WHERE id = ?');
            $stmt->execute([$fileId]);
            flash('success', 'File pendukung berhasil dihapus.');
        }
        redirect('content_detail.php?id=' . $id . '#files');
    }

    if ($action === 'quick_status') {
        require_role(['admin', 'team']);
        $status = (string) ($_POST['status'] ?? 'To Do');
        $allowed = ['To Do', 'On Progress', 'Review', 'Published', 'Archived'];
        if (in_array($status, $allowed, true)) {
            $stmt = $pdo->prepare('UPDATE contents SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
            $stmt->execute([$status, $id]);
            flash('success', 'Status konten diperbarui menjadi ' . $status . '.');
        }
        redirect('content_detail.php?id=' . $id);
    }
}

$stmt = $pdo->prepare("SELECT c.*, u.name AS assignee_name, creator.name AS creator_name
    FROM contents c
    LEFT JOIN users u ON u.id = c.assigned_user_id
    LEFT JOIN users creator ON creator.id = c.created_by
    WHERE c.id = ?");
$stmt->execute([$id]);
$content = $stmt->fetch();
if (!$content) {
    http_response_code(404);
    exit('Konten tidak ditemukan.');
}

$stmt = $pdo->prepare('SELECT f.*, u.name AS uploader_name FROM content_files f LEFT JOIN users u ON u.id = f.uploaded_by WHERE f.content_id = ? ORDER BY datetime(f.created_at) DESC');
$stmt->execute([$id]);
$files = $stmt->fetchAll();

$stmt = $pdo->prepare('SELECT t.*, u.name AS assignee_name FROM tasks t LEFT JOIN users u ON u.id = t.assigned_user_id WHERE t.content_id = ? ORDER BY datetime(t.deadline) ASC');
$stmt->execute([$id]);
$tasks = $stmt->fetchAll();

$stmt = $pdo->prepare('SELECT e.*, u.name AS recorder_name FROM engagements e LEFT JOIN users u ON u.id = e.recorded_by WHERE e.content_id = ?');
$stmt->execute([$id]);
$engagement = $stmt->fetch() ?: null;

$stmt = $pdo->prepare('SELECT f.*, u.name AS feedback_name, u.role AS feedback_role FROM feedbacks f LEFT JOIN users u ON u.id = f.feedback_by WHERE f.content_id = ? ORDER BY datetime(f.created_at) DESC');
$stmt->execute([$id]);
$feedbacks = $stmt->fetchAll();

$pageTitle = 'Detail Konten';
$activePage = 'contents';
require BASE_PATH . '/includes/header.php';
?>

<div class="page-actions">
    <a class="btn btn-ghost" href="contents.php">← Kembali ke Daftar</a>
    <div class="inline-actions">
        <?php if (can_edit_content()): ?>
            <a class="btn btn-secondary" href="content_form.php?id=<?= $id ?>">Edit Konten</a>
            <a class="btn btn-primary" href="tasks.php?content_id=<?= $id ?>#task-form">+ Tambah Tugas</a>
        <?php endif; ?>
    </div>
</div>

<section class="detail-hero">
    <div>
        <div class="detail-chips">
            <span class="platform-pill platform-<?= e(strtolower($content['platform'])) ?>"><?= e($content['platform']) ?></span>
            <span class="category-chip"><?= e($content['category']) ?></span>
            <span class="badge badge-<?= e(status_class($content['status'])) ?>"><?= e($content['status']) ?></span>
        </div>
        <h2><?= e($content['title']) ?></h2>
        <p><?= e($content['content_format']) ?> · Dijadwalkan <?= e(format_datetime($content['scheduled_at'])) ?> WIB</p>
    </div>
    <?php if (can_edit_content()): ?>
        <form method="post" class="quick-status-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="quick_status">
            <input type="hidden" name="content_id" value="<?= $id ?>">
            <label><span>Ubah status cepat</span>
                <select name="status" onchange="this.form.submit()">
                    <?php foreach (['To Do', 'On Progress', 'Review', 'Published', 'Archived'] as $status): ?>
                        <option value="<?= e($status) ?>" <?= selected($content['status'], $status) ?>><?= e($status) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </form>
    <?php endif; ?>
</section>

<div class="detail-layout">
    <div class="detail-main">
        <section class="panel">
            <div class="panel-header"><div><h2>Informasi Konten</h2><p>Data utama perencanaan dan publikasi.</p></div></div>
            <dl class="detail-list">
                <div><dt>Platform</dt><dd><?= e($content['platform']) ?></dd></div>
                <div><dt>Format</dt><dd><?= e($content['content_format']) ?></dd></div>
                <div><dt>Penanggung jawab</dt><dd><?= e($content['assignee_name'] ?: 'Belum ditugaskan') ?></dd></div>
                <div><dt>Dibuat oleh</dt><dd><?= e($content['creator_name'] ?: 'Pengguna') ?></dd></div>
                <div><dt>Jadwal publikasi</dt><dd><?= e(format_datetime($content['scheduled_at'])) ?> WIB</dd></div>
                <div><dt>Terakhir diperbarui</dt><dd><?= e(format_datetime($content['updated_at'])) ?> WIB</dd></div>
            </dl>
            <div class="caption-box">
                <span>Caption / Naskah</span>
                <p><?= nl2br(e($content['caption'] ?: 'Belum ada caption atau naskah.')) ?></p>
            </div>
        </section>

        <section class="panel" id="files">
            <div class="panel-header">
                <div><h2>File Pendukung</h2><p>Foto, video, desain, atau dokumen yang terkait dengan konten.</p></div>
                <?php if (can_edit_content()): ?><a class="text-link" href="content_form.php?id=<?= $id ?>">Unggah melalui Edit</a><?php endif; ?>
            </div>
            <div class="file-list">
                <?php if (!$files): ?><div class="empty-state">Belum ada file pendukung.</div><?php endif; ?>
                <?php foreach ($files as $file): ?>
                    <div class="file-item">
                        <div class="file-icon"><?= str_starts_with($file['mime_type'], 'image/') ? 'IMG' : (str_starts_with($file['mime_type'], 'video/') ? 'VID' : 'DOC') ?></div>
                        <div class="file-copy">
                            <a href="<?= e($file['file_path']) ?>" target="_blank" rel="noopener"><?= e($file['original_name']) ?></a>
                            <span><?= e($file['mime_type']) ?> · <?= number_format(((int) $file['size_bytes']) / 1024, 0, ',', '.') ?> KB · <?= e(format_date($file['created_at'])) ?></span>
                        </div>
                        <?php if (can_edit_content()): ?>
                            <form method="post" data-confirm="Hapus file pendukung ini?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete_file">
                                <input type="hidden" name="content_id" value="<?= $id ?>">
                                <input type="hidden" name="file_id" value="<?= (int) $file['id'] ?>">
                                <button class="btn btn-small btn-danger-ghost" type="submit">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="panel" id="feedback">
            <div class="panel-header"><div><h2>Feedback dan Catatan Revisi</h2><p>Riwayat masukan dari admin, tim, atau humas.</p></div></div>
            <form method="post" class="comment-form">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="feedback">
                <input type="hidden" name="content_id" value="<?= $id ?>">
                <textarea name="note" rows="3" required placeholder="Tulis masukan, hasil review, atau catatan revisi…"></textarea>
                <button class="btn btn-primary" type="submit">Kirim Feedback</button>
            </form>
            <div class="comment-list">
                <?php if (!$feedbacks): ?><div class="empty-state">Belum ada feedback.</div><?php endif; ?>
                <?php foreach ($feedbacks as $feedback): ?>
                    <article class="comment-item">
                        <div class="avatar"><?= e(strtoupper(mb_substr($feedback['feedback_name'] ?: 'P', 0, 1))) ?></div>
                        <div>
                            <div class="comment-head"><strong><?= e($feedback['feedback_name'] ?: 'Pengguna') ?></strong><span><?= e(role_label($feedback['feedback_role'] ?: 'team')) ?> · <?= e(format_datetime($feedback['created_at'])) ?></span></div>
                            <p><?= nl2br(e($feedback['note'])) ?></p>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    </div>

    <aside class="detail-side">
        <section class="panel compact-panel">
            <div class="panel-header"><div><h2>Progres Tugas</h2><p><?= count($tasks) ?> tugas terkait.</p></div></div>
            <div class="mini-task-list">
                <?php if (!$tasks): ?><div class="empty-state">Belum ada tugas.</div><?php endif; ?>
                <?php foreach ($tasks as $task): ?>
                    <div class="mini-task">
                        <span class="badge badge-<?= e(status_class($task['status'])) ?>"><?= e($task['status']) ?></span>
                        <strong><?= e($task['description']) ?></strong>
                        <small><?= e($task['assignee_name'] ?: 'Belum ditugaskan') ?> · <?= e(format_datetime($task['deadline'])) ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
            <a class="btn btn-secondary btn-block" href="tasks.php?content_id=<?= $id ?>">Buka Manajemen Tugas</a>
        </section>

        <section class="panel compact-panel">
            <div class="panel-header"><div><h2>Engagement</h2><p>Performa setelah publikasi.</p></div></div>
            <?php if ($engagement): ?>
                <div class="metric-grid">
                    <div><span>Views</span><strong><?= number_format((int) $engagement['views'], 0, ',', '.') ?></strong></div>
                    <div><span>Reach</span><strong><?= number_format((int) $engagement['reach'], 0, ',', '.') ?></strong></div>
                    <div><span>Likes</span><strong><?= number_format((int) $engagement['likes'], 0, ',', '.') ?></strong></div>
                    <div><span>Komentar</span><strong><?= number_format((int) $engagement['comments'], 0, ',', '.') ?></strong></div>
                    <div><span>Shares</span><strong><?= number_format((int) $engagement['shares'], 0, ',', '.') ?></strong></div>
                    <div><span>Saves</span><strong><?= number_format((int) $engagement['saves'], 0, ',', '.') ?></strong></div>
                </div>
            <?php else: ?>
                <div class="empty-state">Data engagement belum diinput.</div>
            <?php endif; ?>
            <a class="btn btn-secondary btn-block" href="engagement.php?content_id=<?= $id ?>#engagement-form"><?= $engagement ? 'Perbarui Engagement' : 'Input Engagement' ?></a>
        </section>
    </aside>
</div>

<?php require BASE_PATH . '/includes/footer.php'; ?>
