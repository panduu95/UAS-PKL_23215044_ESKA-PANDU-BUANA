<?php

declare(strict_types=1);

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function is_logged_in(): bool
{
    return current_user() !== null;
}

function require_login(): void
{
    if (!is_logged_in()) {
        flash('warning', 'Silakan masuk terlebih dahulu.');
        redirect('login.php');
    }
}

function require_role(array|string $roles): void
{
    require_login();
    $roles = (array) $roles;
    if (!in_array(current_user()['role'], $roles, true)) {
        http_response_code(403);
        exit('Akses ditolak. Anda tidak memiliki hak untuk membuka halaman ini.');
    }
}

function can_manage(): bool
{
    return (current_user()['role'] ?? '') === 'admin';
}

function can_edit_content(): bool
{
    return in_array(current_user()['role'] ?? '', ['admin', 'team'], true);
}
