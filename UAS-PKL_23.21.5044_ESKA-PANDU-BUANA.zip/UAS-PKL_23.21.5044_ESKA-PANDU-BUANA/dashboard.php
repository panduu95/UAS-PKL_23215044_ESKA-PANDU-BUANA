<?php
require __DIR__ . '/bootstrap.php';
require_login();

$pageTitle = 'Dashboard';
$activePage = 'dashboard';

$stats = [];
foreach (['To Do', 'On Progress', 'Review', 'Published'] as $status) {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM contents WHERE status = ?');
    $stmt->execute([$status]);
    $stats[$status] = (int) $stmt->fetchColumn();
}

$totalIdeas = (int) $pdo->query("SELECT COUNT(*) FROM content_ideas WHERE status != 'Archived'")->fetchColumn();
$totalReach = (int) $pdo->query('SELECT COALESCE(SUM(reach), 0) FROM engagements')->fetchColumn();
$totalEngagement = (int) $pdo->query('SELECT COALESCE(SUM(likes + comments + shares + saves), 0) FROM engagements')->fetchColumn();

$upcomingStmt = $pdo->query("SELECT c.*, u.name AS assignee_name
    FROM contents c
    LEFT JOIN users u ON u.id = c.assigned_user_id
    WHERE c.scheduled_at IS NOT NULL AND c.status != 'Archived'
    ORDER BY datetime(c.scheduled_at) ASC
    LIMIT 6");
$upcoming = $upcomingStmt->fetchAll();

$taskSql = "SELECT t.*, c.title AS content_title, u.name AS assignee_name
    FROM tasks t
    JOIN contents c ON c.id = t.content_id
    LEFT JOIN users u ON u.id = t.assigned_user_id
    WHERE t.status != 'Done'";
$params = [];
if (current_user()['role'] === 'team') {
    $taskSql .= ' AND t.assigned_user_id = ?';
    $params[] = current_user()['id'];
}
$taskSql .= ' ORDER BY CASE WHEN t.deadline IS NULL THEN 1 ELSE 0 END, datetime(t.deadline) ASC LIMIT 6';
$stmt = $pdo->prepare($taskSql);
$stmt->execute($params);
$openTasks = $stmt->fetchAll();

$platformRows = $pdo->query("SELECT platform, COUNT(*) AS total FROM contents WHERE status != 'Archived' GROUP BY platform ORDER BY total DESC")->fetchAll();
$statusData = [$stats['To Do'], $stats['On Progress'], $stats['Review'], $stats['Published']];
$platformLabels = array_column($platformRows, 'platform');
$platformData = array_map('intval', array_column($platformRows, 'total'));

require BASE_PATH . '/includes/header.php';
?>

<section class="stats-grid">
    <article class="stat-card">
        <div class="stat-icon">✦</div>
        <div><span>Ide Aktif</span><strong><?= $totalIdeas ?></strong><small>Siap dikembangkan</small></div>
    </article>
    <article class="stat-card">
        <div class="stat-icon">◔</div>
        <div><span>Sedang Dikerjakan</span><strong><?= $stats['On Progress'] ?></strong><small>Konten on progress</small></div>
    </article>
    <article class="stat-card">
        <div class="stat-icon">✓</div>
        <div><span>Sudah Dipublikasikan</span><strong><?= $stats['Published'] ?></strong><small>Konten published</small></div>
    </article>
    <article class="stat-card">
        <div class="stat-icon">↗</div>
        <div><span>Total Jangkauan</span><strong><?= number_format($totalReach, 0, ',', '.') ?></strong><small><?= number_format($totalEngagement, 0, ',', '.') ?> interaksi</small></div>
    </article>
</section>

<section class="dashboard-grid">
    <article class="panel chart-panel">
        <div class="panel-header">
            <div><h2>Status Produksi Konten</h2><p>Ringkasan progres seluruh konten.</p></div>
            <a class="text-link" href="contents.php">Lihat data</a>
        </div>
        <div class="chart-wrap"><canvas id="statusChart" width="560" height="250"></canvas></div>
        <div class="legend-row">
            <span><i class="legend-dot dot-1"></i>To Do: <?= $stats['To Do'] ?></span>
            <span><i class="legend-dot dot-2"></i>On Progress: <?= $stats['On Progress'] ?></span>
            <span><i class="legend-dot dot-3"></i>Review: <?= $stats['Review'] ?></span>
            <span><i class="legend-dot dot-4"></i>Published: <?= $stats['Published'] ?></span>
        </div>
    </article>

    <article class="panel">
        <div class="panel-header">
            <div><h2>Distribusi Platform</h2><p>Jumlah konten per platform.</p></div>
        </div>
        <div class="chart-wrap chart-wrap-small"><canvas id="platformChart" width="420" height="250"></canvas></div>
    </article>
</section>

<section class="dashboard-grid dashboard-grid-equal">
    <article class="panel">
        <div class="panel-header">
            <div><h2>Jadwal Publikasi</h2><p>Konten yang sudah memiliki tanggal tayang.</p></div>
            <a class="text-link" href="calendar.php">Buka kalender</a>
        </div>
        <div class="timeline-list">
            <?php if (!$upcoming): ?>
                <div class="empty-state">Belum ada jadwal publikasi.</div>
            <?php endif; ?>
            <?php foreach ($upcoming as $content): ?>
                <a class="timeline-item" href="content_detail.php?id=<?= (int) $content['id'] ?>">
                    <div class="date-box"><strong><?= e(format_date($content['scheduled_at'], 'd')) ?></strong><span><?= e(strtoupper(format_date($content['scheduled_at'], 'M'))) ?></span></div>
                    <div class="timeline-copy">
                        <strong><?= e($content['title']) ?></strong>
                        <span><?= e($content['platform']) ?> · <?= e($content['content_format']) ?> · <?= e(format_date($content['scheduled_at'], 'H:i')) ?> WIB</span>
                    </div>
                    <span class="badge badge-<?= e(status_class($content['status'])) ?>"><?= e($content['status']) ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="panel">
        <div class="panel-header">
            <div><h2>Tugas Prioritas</h2><p>Tugas aktif berdasarkan tenggat terdekat.</p></div>
            <a class="text-link" href="tasks.php">Kelola tugas</a>
        </div>
        <div class="task-list">
            <?php if (!$openTasks): ?>
                <div class="empty-state">Semua tugas telah selesai.</div>
            <?php endif; ?>
            <?php foreach ($openTasks as $task): ?>
                <div class="task-item">
                    <div class="task-check <?= $task['status'] === 'Review' ? 'review' : '' ?>">✓</div>
                    <div class="task-copy">
                        <strong><?= e($task['description']) ?></strong>
                        <span><?= e($task['content_title']) ?> · <?= e($task['assignee_name'] ?: 'Belum ditugaskan') ?></span>
                    </div>
                    <div class="task-meta">
                        <span class="badge badge-<?= e(status_class($task['status'])) ?>"><?= e($task['status']) ?></span>
                        <small><?= e(format_datetime($task['deadline'])) ?></small>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </article>
</section>

<script>
window.dashboardCharts = {
    status: <?= json_encode($statusData, JSON_THROW_ON_ERROR) ?>,
    platformLabels: <?= json_encode($platformLabels, JSON_THROW_ON_ERROR) ?>,
    platformData: <?= json_encode($platformData, JSON_THROW_ON_ERROR) ?>
};
</script>
<?php require BASE_PATH . '/includes/footer.php'; ?>
