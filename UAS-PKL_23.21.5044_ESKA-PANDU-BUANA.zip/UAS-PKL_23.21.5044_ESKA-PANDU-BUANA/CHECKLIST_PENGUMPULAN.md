# Checklist Pengumpulan UAS

- [ ] Buat repository GitHub **Public**.
- [ ] Gunakan nama repository: `UAS-PKL_23.21.5044_ESKA-PANDU-BUANA`.
- [ ] Upload seluruh folder dan file proyek.
- [ ] Pastikan `database/schema.sql` ikut terunggah.
- [ ] Pastikan `README.md` tampil pada halaman utama repository.
- [ ] Jangan upload file `storage/content_planner.sqlite` yang berisi perubahan pribadi.
- [ ] Jangan upload password pribadi atau data rahasia instansi.
- [ ] Jalankan aplikasi lokal dan cek semua menu.
- [ ] Uji login Admin, Tim Konten, dan Humas.
- [ ] Salin link repository GitHub.
- [ ] Bila berhasil deploy, tambahkan link website pada README.
- [ ] Isi formulir/media UAS dengan link repository dan link website (opsional).
- [ ] Siapkan demo sesuai `PANDUAN_DEMO_UAS.md`.
