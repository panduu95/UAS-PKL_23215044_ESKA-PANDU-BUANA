<?php

declare(strict_types=1);

session_start();

define('BASE_PATH', __DIR__);

define('APP_NAME', 'Konten Planner SMK BPA');

date_default_timezone_set('Asia/Jakarta');

require_once BASE_PATH . '/includes/functions.php';
require_once BASE_PATH . '/config/database.php';
require_once BASE_PATH . '/includes/auth.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
