PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'team', 'humas')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS content_ideas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL DEFAULT 'Informasi',
    proposer_id INTEGER,
    status TEXT NOT NULL DEFAULT 'New' CHECK (status IN ('New', 'Approved', 'Archived')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (proposer_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS contents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Informasi',
    platform TEXT NOT NULL CHECK (platform IN ('Instagram', 'TikTok', 'YouTube', 'Facebook', 'Website')),
    content_format TEXT NOT NULL CHECK (content_format IN ('Feed', 'Reels', 'Story', 'Video', 'Poster', 'Artikel')),
    caption TEXT,
    scheduled_at TEXT,
    status TEXT NOT NULL DEFAULT 'To Do' CHECK (status IN ('To Do', 'On Progress', 'Review', 'Published', 'Archived')),
    assigned_user_id INTEGER,
    created_by INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content_id INTEGER NOT NULL,
    assigned_user_id INTEGER,
    description TEXT NOT NULL,
    deadline TEXT,
    status TEXT NOT NULL DEFAULT 'To Do' CHECK (status IN ('To Do', 'On Progress', 'Review', 'Done')),
    created_by INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (content_id) REFERENCES contents(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS content_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content_id INTEGER NOT NULL,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL DEFAULT 0,
    file_path TEXT NOT NULL,
    uploaded_by INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (content_id) REFERENCES contents(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS engagements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content_id INTEGER NOT NULL UNIQUE,
    views INTEGER NOT NULL DEFAULT 0,
    likes INTEGER NOT NULL DEFAULT 0,
    comments INTEGER NOT NULL DEFAULT 0,
    shares INTEGER NOT NULL DEFAULT 0,
    reach INTEGER NOT NULL DEFAULT 0,
    saves INTEGER NOT NULL DEFAULT 0,
    recorded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    recorded_by INTEGER,
    FOREIGN KEY (content_id) REFERENCES contents(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS feedbacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content_id INTEGER NOT NULL,
    note TEXT NOT NULL,
    feedback_by INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (content_id) REFERENCES contents(id) ON DELETE CASCADE,
    FOREIGN KEY (feedback_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_contents_status ON contents(status);
CREATE INDEX IF NOT EXISTS idx_contents_schedule ON contents(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_tasks_assignee ON tasks(assigned_user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_deadline ON tasks(deadline);

INSERT OR IGNORE INTO users (id, name, email, password, role) VALUES
(1, 'Admin Media Sosial', 'admin@smkbpa.sch.id', '$2y$12$tFEGkJ2jls1JRUpTEOj0We6G.qljqzkePjRlNmOuD7eQwmX/QYjSS', 'admin'),
(2, 'Eska Pandu Buana', 'eska@smkbpa.sch.id', '$2y$12$v9fy4d0RXNKFcaJZoyHK9.oG1pV0jFmNPpHm7tsYJJYO753hChf2.', 'team'),
(3, 'Humas SMK BPA', 'humas@smkbpa.sch.id', '$2y$12$VFPeV03zBKeE2ofs.cQD1O9rzCHkmH72wCT1hJ3jtGL7E7sI5apfy', 'humas');

INSERT OR IGNORE INTO content_ideas (id, title, description, category, proposer_id, status, created_at) VALUES
(1, 'Profil Jurusan TJKT', 'Video singkat fasilitas laboratorium, kegiatan praktik, dan peluang kerja lulusan TJKT.', 'Promosi', 2, 'Approved', '2026-07-01 08:00:00'),
(2, 'Tips Aman Menggunakan Internet', 'Carousel edukasi tentang kata sandi kuat, phishing, dan privasi digital.', 'Edukasi', 2, 'New', '2026-07-03 09:15:00'),
(3, 'Back to School 2026', 'Konten penyambutan peserta didik pada awal tahun pelajaran.', 'Kegiatan Sekolah', 1, 'Approved', '2026-07-05 10:30:00');

INSERT OR IGNORE INTO contents (id, title, category, platform, content_format, caption, scheduled_at, status, assigned_user_id, created_by, created_at, updated_at) VALUES
(1, 'Video Profil Jurusan TJKT', 'Promosi', 'Instagram', 'Reels', 'Kenali lebih dekat Jurusan Teknik Jaringan Komputer dan Telekomunikasi di SMK Bhakti Praja Adiwerna. Siap belajar, berkarya, dan terhubung dengan masa depan!', '2026-07-16 10:00:00', 'On Progress', 2, 1, '2026-07-02 08:30:00', '2026-07-10 14:00:00'),
(2, 'Pamflet Back to School', 'Kegiatan Sekolah', 'Instagram', 'Feed', 'Selamat datang kembali di sekolah! Mari mulai tahun pelajaran baru dengan semangat, disiplin, dan karya terbaik.', '2026-07-20 07:00:00', 'Review', 2, 1, '2026-07-05 11:00:00', '2026-07-12 16:20:00'),
(3, 'Dokumentasi Class Meeting', 'Kegiatan Siswa', 'TikTok', 'Video', 'Keseruan Class Meeting SMK Bhakti Praja Adiwerna. Kompak, sportif, dan penuh semangat!', '2026-06-28 15:00:00', 'Published', 2, 1, '2026-06-24 09:00:00', '2026-06-28 15:05:00'),
(4, 'Informasi Daftar Ulang', 'Informasi', 'Instagram', 'Story', 'Informasi jadwal dan persyaratan daftar ulang peserta didik baru.', '2026-07-14 08:00:00', 'Published', 1, 1, '2026-07-11 09:00:00', '2026-07-14 08:02:00'),
(5, 'Tips Keamanan Akun', 'Edukasi', 'Instagram', 'Feed', 'Lindungi akunmu dengan kata sandi kuat dan verifikasi dua langkah.', '2026-07-24 11:30:00', 'To Do', 2, 1, '2026-07-13 13:00:00', '2026-07-13 13:00:00');

INSERT OR IGNORE INTO tasks (id, content_id, assigned_user_id, description, deadline, status, created_by, created_at, updated_at) VALUES
(1, 1, 2, 'Ambil video laboratorium dan praktik konfigurasi jaringan.', '2026-07-15 12:00:00', 'On Progress', 1, '2026-07-02 09:00:00', '2026-07-10 14:00:00'),
(2, 1, 2, 'Edit video vertikal berdurasi 45–60 detik dan tambahkan subtitle.', '2026-07-16 08:00:00', 'To Do', 1, '2026-07-02 09:05:00', '2026-07-02 09:05:00'),
(3, 2, 2, 'Finalisasi desain pamflet sesuai identitas visual sekolah.', '2026-07-18 15:00:00', 'Review', 1, '2026-07-05 11:30:00', '2026-07-12 16:20:00'),
(4, 5, 2, 'Susun materi singkat dan desain carousel lima slide.', '2026-07-22 15:00:00', 'To Do', 1, '2026-07-13 13:15:00', '2026-07-13 13:15:00');

INSERT OR IGNORE INTO engagements (content_id, views, likes, comments, shares, reach, saves, recorded_at, recorded_by) VALUES
(3, 7850, 624, 31, 76, 6900, 92, '2026-07-02 09:00:00', 1),
(4, 2410, 180, 12, 36, 2180, 44, '2026-07-15 08:00:00', 1);

INSERT OR IGNORE INTO feedbacks (content_id, note, feedback_by, created_at) VALUES
(2, 'Logo sekolah sudah sesuai. Mohon perbesar informasi tanggal dan tambahkan ajakan untuk hadir tepat waktu.', 3, '2026-07-12 15:45:00');
