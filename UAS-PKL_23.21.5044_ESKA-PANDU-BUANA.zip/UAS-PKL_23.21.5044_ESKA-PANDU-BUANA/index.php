<?php
require __DIR__ . '/bootstrap.php';
redirect(is_logged_in() ? 'dashboard.php' : 'login.php');
